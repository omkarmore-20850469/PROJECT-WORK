import { Component, computed, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { NgIf } from '@angular/common';
import { ApiService } from './core/api.service';
@Component({selector:'app-root',standalone:true,imports:[RouterOutlet,RouterLink,RouterLinkActive,NgIf],template:`
<div class="app-shell">
  <aside class="sidebar" *ngIf="api.user()">
    <a class="brand" routerLink="/"><span class="brand-mark">✦</span><span>vita<span class="brand-light">pulse</span><small>YOUR WELLNESS SPACE</small></span></a>
    <div class="nav-label">WORKSPACE</div>
    <a class="nav-item" routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}"><span>◫</span> Overview</a>
    <a class="nav-item" routerLink="/training" routerLinkActive="active"><span>↗</span> Start workout</a>
    <a class="nav-item" routerLink="/history" routerLinkActive="active"><span>▤</span> Workout history</a>
    <div class="sidebar-bottom"><div class="mini-profile"><div class="avatar">{{ initials() }}</div><div class="profile-copy"><strong>{{api.user()?.displayName}}</strong><small>Personal account</small></div><button class="icon-btn" title="Sign out" (click)="logout()">↪</button></div><div class="sidebar-note"><span class="pulse"></span> Every move counts.</div></div>
  </aside>
  <main class="main-area" [class.auth-main]="!api.user()">
    <header class="topbar" *ngIf="api.user()"><div><div class="eyebrow">YOUR PERSONAL FITNESS SPACE</div><h2>{{ pageTitle() }}</h2></div><div class="topbar-right"><span class="date-chip">◷ &nbsp; {{today}}</span><div class="avatar avatar-small">{{initials()}}</div></div></header>
    <router-outlet />
    <footer class="footer" *ngIf="api.user()">Built for progress, not perfection <span>✦</span></footer>
  </main>
</div>
<div class="toast" *ngIf="api.toast()" role="status">{{api.toast()}}</div>
`})
export class AppComponent {
 today=new Date().toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric'});
 constructor(public api:ApiService,private router:Router){}
 initials(){return (this.api.user()?.displayName||'FT').split(' ').map(x=>x[0]).join('').slice(0,2).toUpperCase();}
 pageTitle(){const p=this.router.url;return p.includes('training')?'Start a workout':p.includes('history')?'Your workout history':'Your overview';}
 logout(){this.api.logout();this.router.navigateByUrl('/login');}
}
