import { Routes } from '@angular/router';
import { LoginComponent, SignupComponent } from './auth/auth.components';
import { DashboardComponent, TrainingComponent, HistoryComponent } from './training/training.components';
import { authGuard, guestGuard } from './core/guards';
export const routes: Routes = [
 {path:'',component:DashboardComponent,canActivate:[authGuard],title:'Dashboard | VitaPulse'},
 {path:'training',component:TrainingComponent,canActivate:[authGuard],title:'Start workout | VitaPulse'},
 {path:'history',component:HistoryComponent,canActivate:[authGuard],title:'Workout history | VitaPulse'},
 {path:'login',component:LoginComponent,canActivate:[guestGuard],title:'Sign in | VitaPulse'},
 {path:'signup',component:SignupComponent,canActivate:[guestGuard],title:'Create account | VitaPulse'},
 {path:'**',redirectTo:''}
];
