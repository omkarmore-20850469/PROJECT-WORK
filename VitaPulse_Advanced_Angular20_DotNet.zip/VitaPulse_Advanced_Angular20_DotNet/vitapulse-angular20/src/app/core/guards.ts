import { inject } from '@angular/core'; import { CanActivateFn, Router } from '@angular/router'; import { ApiService } from './api.service';
export const authGuard:CanActivateFn=()=>inject(ApiService).user()?true:inject(Router).createUrlTree(['/login']);
export const guestGuard:CanActivateFn=()=>inject(ApiService).user()?inject(Router).createUrlTree(['/']):true;
