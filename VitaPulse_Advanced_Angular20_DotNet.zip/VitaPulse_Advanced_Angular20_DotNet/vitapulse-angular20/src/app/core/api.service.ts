import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthResponse, Exercise, Workout } from './models';
@Injectable({providedIn:'root'})
export class ApiService {
  readonly baseUrl = 'http://localhost:5080/api';
  readonly user = signal<{email:string;displayName:string}|null>(this.readUser());
  readonly toast = signal('');
  constructor(private http: HttpClient) {}
  private readUser() { try { const s=localStorage.getItem('vitapulse_user'); return s?JSON.parse(s):null; } catch { return null; } }
  async request<T>(url:string, method:'GET'|'POST'|'DELETE'='GET', body?:unknown):Promise<T> {
    try { return await firstValueFrom(method==='GET'?this.http.get<T>(this.baseUrl+url):method==='DELETE'?this.http.delete<T>(this.baseUrl+url):this.http.post<T>(this.baseUrl+url,body)); }
    catch(e:any) { const message=e?.error?.message || e?.error?.title || (e?.status===0?'Cannot connect to API. Start the .NET backend on port 5080.':`Request failed (${e?.status ?? 'unknown'}).`); this.notify(message); throw new Error(message); }
  }
  async login(email:string,password:string) { const r=await this.request<AuthResponse>('/auth/login','POST',{email,password}); this.saveAuth(r); }
  async register(displayName:string,email:string,password:string) { const r=await this.request<AuthResponse>('/auth/register','POST',{displayName,email,password}); this.saveAuth(r); }
  private saveAuth(r:AuthResponse) { localStorage.setItem('vitapulse_token',r.token); const u={email:r.email,displayName:r.displayName}; localStorage.setItem('vitapulse_user',JSON.stringify(u)); this.user.set(u); }
  logout() { localStorage.removeItem('vitapulse_token');localStorage.removeItem('vitapulse_user');this.user.set(null); }
  exercises() { return this.request<Exercise[]>('/exercises'); }
  history() { return this.request<Workout[]>('/workouts'); }
  saveWorkout(w:{exerciseId:string;duration:number;calories:number;state:'completed'|'cancelled'}) { return this.request<Workout>('/workouts','POST',{...w,exerciseId:Number(w.exerciseId)}); }
  notify(message:string) { this.toast.set(message); setTimeout(()=>{if(this.toast()===message)this.toast.set('');},4000); }
}
