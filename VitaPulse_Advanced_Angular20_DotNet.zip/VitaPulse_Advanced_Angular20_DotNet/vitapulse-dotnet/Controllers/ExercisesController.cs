using FitnessTracker.Api.Data;using FitnessTracker.Api.DTOs;using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;
namespace FitnessTracker.Api.Controllers;
[ApiController][Route("api/[controller]")][Authorize]
public sealed class ExercisesController(AppDbContext db):ControllerBase{[HttpGet]public async Task<ActionResult<IEnumerable<ExerciseResponse>>> GetAll()=>Ok(await db.Exercises.AsNoTracking().OrderBy(e=>e.Id).Select(e=>new ExerciseResponse(e.Id.ToString(),e.Name,e.Duration,e.Calories,e.Category,e.Description)).ToListAsync());}
