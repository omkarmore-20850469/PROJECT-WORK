using System.Text;
using System.Text.Json.Serialization;
using FitnessTracker.Api.Data;
using FitnessTracker.Api.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers().AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddEndpointsApiExplorer(); builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));
var jwtKey = builder.Configuration["Jwt:Key"] ?? throw new InvalidOperationException("JWT key is not configured.");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o => { o.TokenValidationParameters = new TokenValidationParameters { ValidateIssuer=true,ValidateAudience=true,ValidateLifetime=true,ValidateIssuerSigningKey=true,ValidIssuer=builder.Configuration["Jwt:Issuer"],ValidAudience=builder.Configuration["Jwt:Audience"],IssuerSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),ClockSkew=TimeSpan.FromSeconds(30) }; });
builder.Services.AddAuthorization();builder.Services.AddScoped<FitnessTracker.Api.Services.TokenService>();
builder.Services.AddCors(o=>o.AddPolicy("Angular",p=>p.WithOrigins("http://localhost:4200","https://localhost:4200").AllowAnyHeader().AllowAnyMethod()));
var app=builder.Build();
using(var scope=app.Services.CreateScope()){var db=scope.ServiceProvider.GetRequiredService<AppDbContext>();await db.Database.EnsureCreatedAsync();if(!await db.Exercises.AnyAsync()){db.Exercises.AddRange(new Exercise{Name="Running",Duration=30,Calories=280,Category="CARDIO",Description="Find a comfortable rhythm and build endurance."},new Exercise{Name="Cycling",Duration=45,Calories=350,Category="CARDIO",Description="A steady ride to get your energy moving."},new Exercise{Name="Push Ups",Duration=15,Calories=120,Category="STRENGTH",Description="A simple bodyweight session for upper-body strength."},new Exercise{Name="Squats",Duration=20,Calories=160,Category="STRENGTH",Description="Build lower-body strength one rep at a time."},new Exercise{Name="Yoga & Stretching",Duration=25,Calories=100,Category="RECOVERY",Description="Reset, stretch, and reconnect with your breathing."},new Exercise{Name="Walking",Duration=30,Calories=140,Category="LOW IMPACT",Description="A low-pressure way to make movement part of your day."});await db.SaveChangesAsync();}}
app.UseMiddleware<FitnessTracker.Api.Services.ErrorHandlingMiddleware>();app.UseCors("Angular");app.UseAuthentication();app.UseAuthorization();app.UseSwagger();app.UseSwaggerUI();app.MapControllers();app.MapGet("/health",()=>Results.Ok(new{status="healthy",service="VitaPulse API"}));app.Run();
