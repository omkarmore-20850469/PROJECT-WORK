# VitaPulse — Smart Fitness & Wellness Platform

VitaPulse is a polished fitness tracking application built with **Angular 20** and **ASP.NET Core 8 Web API**. It combines account-based workout tracking with activity insights and a responsive dashboard.

## What's new in this edition
- Rebranded product identity and refreshed responsive UI.
- Weekly activity chart with a 150-minute movement goal and progress indicator.
- Consecutive-day activity streak based on completed workouts.
- Workout catalogue search and category filters (cardio, strength, recovery and low impact).
- Live workout timer, progress ring, estimated calories and completion history.
- JWT authentication, BCrypt password hashing, user-scoped workout history and SQLite persistence.
- Empty states, inline API feedback, mobile layouts and keyboard-friendly search controls.

## Requirements
- Node.js 20.19+ or 22.12+ and npm
- .NET 8 SDK

## Project layout
- `vitapulse-angular20/` — Angular 20 frontend
- `vitapulse-dotnet/` — ASP.NET Core Web API, JWT authentication, EF Core and SQLite
- `start-frontend.ps1` / `start-backend.ps1` — optional Windows PowerShell launch scripts

## Run locally
Open two PowerShell terminals from the extracted project root.

**Terminal 1 — API**
```powershell
cd .\vitapulse-dotnet
dotnet restore
dotnet build
dotnet run
```
API: http://localhost:5080 · Swagger: http://localhost:5080/swagger · Health: http://localhost:5080/health

**Terminal 2 — frontend**
```powershell
cd .\vitapulse-angular20
npm install
npm start
```
Open http://localhost:4200, create an account, and keep the API running. Starter exercises are seeded automatically.

## API routes
- `POST /api/auth/register` — register
- `POST /api/auth/login` — sign in and receive a JWT
- `GET /api/auth/me` — current account (JWT required)
- `GET /api/exercises` — available exercises (JWT required)
- `GET /api/workouts` — current user's workout history (JWT required)
- `POST /api/workouts` — save a completed or early-finished session (JWT required)
- `DELETE /api/workouts/{id}` — delete a workout owned by the current user (JWT required)

## Important notes
- This migration uses a .NET API and SQLite rather than the original Firebase setup. Firebase configuration is not required.
- The JWT signing key in `vitapulse-dotnet/appsettings.json` is for local development only. Replace it with a secure secret before deployment.
- The activity goal is a motivational in-app target, not medical advice. Calories are estimates.
- To reset local data, stop the API and delete `vitapulse.db` in the backend folder; it will be recreated on startup.
