# RescueNET BLE protocol (v1 draft)

The web app (Web Bluetooth, central role) and a native Android app (central + peripheral) share one GATT contract.

| Item | Value |
|---|---|
| Service UUID | `6e5a0001-b5a3-f393-e0a9-e50e24dcca9e` |
| Packet characteristic | `6e5a0002-b5a3-f393-e0a9-e50e24dcca9e` |
| Properties | Write Without Response, Notify |
| Framing | One JSON packet per line, terminated by `\n`. Split into chunks of at most 180 bytes (default ATT MTU safe). |

## Packet (same JSON as `POST /api/mesh-ingest/sync-payload`)
```json
{ "messageId": "sha256(citizenId|createdAtMs) lowercase hex", "citizenId": "CIT-1042",
  "latitude": 19.076, "longitude": 72.8777, "riskScore": 4, "priority": 97, "category": "Trapped",
  "people": 2, "note": "…", "createdAtMs": 1760000000000, "hopPath": ["1042","B-04"], "batteryPct": 41 }
```

## Node behaviour (what the browser simulation models and the Android app must implement)
1. **Advertise** the service UUID while MESH is on; **scan** for it and connect to neighbours.
2. **Store before forward.** Persist every packet in a local queue until a neighbour acknowledges it (a successful write) or a gateway uploads it.
3. **Dedupe** by `messageId` (a seen-set per node). Drop repeats and never re-forward them.
4. **Priority order.** Always send the highest `priority` first. Critical packets (>= 90) may be sent to two neighbours for redundancy.
5. **Routing.** Prefer neighbours with fewer hops to a gateway; if a link fails, keep the packet and pick another neighbour. Append your node label to `hopPath`; drop when TTL (default 14) is exhausted.
6. **Gateway.** A node with internet uploads queued packets to `/api/mesh-ingest/sync-payload` with `X-Gateway-Key` and `X-Gateway-Id`. The server recomputes the ID, validates ranges and drops duplicates.

## Browser limits (why a native app is still required)
Web Bluetooth can scan with a chooser and connect to a peripheral, but a web page cannot advertise, cannot run in the background and cannot accept inbound connections. iOS Safari does not support Web Bluetooth. Real phone-to-phone relaying therefore needs the Android (foreground service) and/or iOS native app.
