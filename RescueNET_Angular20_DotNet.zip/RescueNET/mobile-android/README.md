# RescueMesh Android starter

This standalone Android Studio project includes a polished citizen-side screen, runtime BLE-permission checks, Bluetooth adapter readiness status, and a SharedPreferences-backed local SOS queue.

## Open and run

1. Open the `mobile-android` folder in Android Studio.
2. Use JDK 17 and allow Gradle sync to download its declared Android/Kotlin plugins.
3. Run the `app` module on an Android device (BLE readiness checks should be tested on real hardware).

## Current capability boundary

The app currently **does not** scan/advertise a RescueMesh GATT service, exchange packets with other devices, run a foreground relay service, forward queue entries to a gateway, or acknowledge uploads. The SOS queue is local storage only. Those features require implementation and physical-device testing. Granting Bluetooth permission or turning Bluetooth on does not itself make a phone relay messages.
