package com.rescuemesh.mobile

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * RescueMesh citizen-side Android starter.
 * SOS reports can be stored locally. BLE GATT discovery, transfer, background relay,
 * gateway upload and acknowledgement handling are deliberately not represented as complete.
 */
class MainActivity : Activity() {
    private val requestCode = 901
    private lateinit var bluetoothStatus: TextView
    private lateinit var queueSummary: TextView
    private lateinit var noteInput: EditText
    private lateinit var peopleInput: EditText
    private lateinit var riskSpinner: Spinner
    private lateinit var primaryAction: Button

    private val colors = object {
        val ink = Color.rgb(29, 48, 68)
        val muted = Color.rgb(123, 143, 160)
        val background = Color.rgb(244, 247, 250)
        val coral = Color.rgb(230, 83, 73)
        val paleRed = Color.rgb(255, 240, 238)
        val paleGreen = Color.rgb(234, 248, 241)
        val green = Color.rgb(47, 137, 99)
        val line = Color.rgb(226, 234, 240)
        val white = Color.WHITE
    }

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_ADVERTISE
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = colors.ink
        window.navigationBarColor = colors.background
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(colors.background)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(colors.ink, 18)
        }
        hero.addView(label("RESCUEMESH  /  FIELD RESPONSE", 10f, Color.rgb(255, 160, 151), true))
        hero.addView(label("Help can travel\noffline.", 28f, colors.white, true).apply {
            setPadding(0, dp(10), 0, dp(8))
        })
        hero.addView(label("Create a distress report and keep it on this device until a compatible relay or gateway workflow is available.", 13f, Color.rgb(190, 207, 219), false))
        val heroFooter = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, 0)
        }
        heroFooter.addView(pill("●  LOCAL QUEUE", colors.paleGreen, colors.green))
        heroFooter.addView(label("  No internet required to save", 10f, Color.rgb(174, 194, 207), false))
        hero.addView(heroFooter)
        content.addView(hero, fullWidth())

        val statusCard = card()
        statusCard.addView(sectionTitle("Bluetooth readiness", "Connection state only — relay transport is not implemented yet"))
        bluetoothStatus = label("Checking Bluetooth permissions…", 12f, colors.muted, false).apply {
            setPadding(0, dp(12), 0, dp(14))
        }
        statusCard.addView(bluetoothStatus)
        val statusActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val checkButton = button("Check Bluetooth", false).apply { setOnClickListener { checkBluetooth() } }
        val settingsButton = button("Open settings", true).apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        }
        statusActions.addView(checkButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        statusActions.addView(settingsButton, LinearLayout.LayoutParams(dp(132), dp(42)).apply { leftMargin = dp(8) })
        statusCard.addView(statusActions)
        content.addView(statusCard, fullWidth().apply { topMargin = dp(14) })

        val formCard = card()
        formCard.addView(sectionTitle("Create SOS report", "Keep details brief and specific"))
        formCard.addView(label("PRIORITY", 9f, colors.muted, true).apply { setPadding(0, dp(16), 0, dp(7)) })
        riskSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Critical · immediate danger", "High · urgent assistance", "Medium · assistance needed", "Low · non-urgent support"))
            setSelection(0)
            background = rounded(colors.background, 8, colors.line)
            setPadding(dp(9), dp(4), dp(9), dp(4))
        }
        formCard.addView(riskSpinner, fullWidth().apply { height = dp(44) })

        formCard.addView(label("PEOPLE AFFECTED", 9f, colors.muted, true).apply { setPadding(0, dp(13), 0, dp(7)) })
        peopleInput = field("1", false).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(4))
        }
        formCard.addView(peopleInput, fullWidth().apply { height = dp(44) })

        formCard.addView(label("SITUATION / NOTE", 9f, colors.muted, true).apply { setPadding(0, dp(13), 0, dp(7)) })
        noteInput = field("Example: trapped indoors, water rising", true).apply {
            minLines = 3
            maxLines = 5
            filters = arrayOf(InputFilter.LengthFilter(280))
        }
        formCard.addView(noteInput, fullWidth().apply { height = dp(100) })

        primaryAction = button("＋  Save SOS to this device", true).apply {
            setOnClickListener { saveLocalSos() }
        }
        formCard.addView(primaryAction, fullWidth().apply { topMargin = dp(16); height = dp(47) })
        content.addView(formCard, fullWidth().apply { topMargin = dp(14) })

        val queueCard = card()
        queueCard.addView(sectionTitle("Local SOS queue", "Saved items remain on this Android device"))
        queueSummary = label("0 reports stored", 23f, colors.ink, true).apply { setPadding(0, dp(11), 0, dp(4)) }
        queueCard.addView(queueSummary)
        queueCard.addView(label("The queue is local only in this starter. It is not automatically forwarded to nearby phones or uploaded to the command API.", 11f, colors.muted, false))
        content.addView(queueCard, fullWidth().apply { topMargin = dp(14) })

        val notice = TextView(this).apply {
            text = "SAFETY NOTICE\nRescueMesh is a prototype, not an official emergency service. Keep local emergency numbers and other communication options available."
            textSize = 11f
            setTextColor(Color.rgb(150, 105, 70))
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(Color.rgb(255, 248, 240), 9, Color.rgb(244, 224, 204))
        }
        content.addView(notice, fullWidth().apply { topMargin = dp(14) })
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(page)
        updateQueueCount()

        if (requiredPermissions.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) checkBluetooth()
        else requestPermissions(requiredPermissions, requestCode)
    }

    private fun saveLocalSos() {
        val people = peopleInput.text.toString().toIntOrNull()?.coerceIn(1, 1000) ?: 1
        val risk = when (riskSpinner.selectedItemPosition) { 0 -> 4; 1 -> 3; 2 -> 2; else -> 1 }
        val note = noteInput.text.toString().trim()
        val id = "SOS-" + UUID.randomUUID().toString().take(8).uppercase()
        val item = JSONObject().apply {
            put("messageId", id)
            put("citizenId", "CIT-" + UUID.randomUUID().toString().take(4).uppercase())
            put("createdAtMs", System.currentTimeMillis())
            put("riskScore", risk)
            put("people", people)
            put("note", note)
            put("status", "Local queue")
        }
        val preferences = getSharedPreferences("rescuemesh", Context.MODE_PRIVATE)
        val items = JSONArray(preferences.getString("queued_sos", "[]"))
        items.put(item)
        preferences.edit().putString("queued_sos", items.toString()).putString("last_demo_sos", id).apply()
        noteInput.setText("")
        peopleInput.setText("1")
        updateQueueCount()
        bluetoothStatus.text = "Saved $id locally. Bluetooth readiness is checked separately; the BLE packet exchange is not implemented in this starter."
        bluetoothStatus.setTextColor(colors.green)
    }

    private fun updateQueueCount() {
        val items = JSONArray(getSharedPreferences("rescuemesh", Context.MODE_PRIVATE).getString("queued_sos", "[]"))
        queueSummary.text = "${items.length()} ${if (items.length() == 1) "report" else "reports"} stored"
    }

    private fun checkBluetooth() {
        if (!requiredPermissions.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) {
            bluetoothStatus.text = "Bluetooth permissions have not been granted. Grant them to check device readiness."
            bluetoothStatus.setTextColor(colors.coral)
            requestPermissions(requiredPermissions, requestCode)
            return
        }
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = manager.adapter
        when {
            adapter == null -> {
                bluetoothStatus.text = "Bluetooth is not supported on this device. Local SOS saving still works."
                bluetoothStatus.setTextColor(colors.coral)
            }
            !adapter.isEnabled -> {
                bluetoothStatus.text = "Bluetooth is turned off. Open Android Bluetooth settings to enable it. Local SOS saving still works."
                bluetoothStatus.setTextColor(colors.coral)
            }
            else -> {
                bluetoothStatus.text = "Bluetooth is enabled. This confirms adapter readiness only; discovery, GATT transfer, multi-hop forwarding and gateway acknowledgements are not implemented."
                bluetoothStatus.setTextColor(colors.green)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) checkBluetooth()
        else {
            bluetoothStatus.text = "Bluetooth permissions were not granted. Local SOS saving remains available."
            bluetoothStatus.setTextColor(colors.coral)
        }
    }

    private fun sectionTitle(title: String, subtitle: String): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(label(title, 15f, colors.ink, true))
        wrap.addView(label(subtitle, 10f, colors.muted, false).apply { setPadding(0, dp(4), 0, 0) })
        return wrap
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(colors.white, 13, colors.line)
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.START
        includeFontPadding = true
    }

    private fun field(hintValue: String, multiline: Boolean) = EditText(this).apply {
        hint = hintValue
        textSize = 12f
        setTextColor(colors.ink)
        setHintTextColor(colors.muted)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = rounded(colors.background, 8, colors.line)
        if (multiline) { gravity = Gravity.TOP or Gravity.START; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        else inputType = android.text.InputType.TYPE_CLASS_TEXT
    }

    private fun button(textValue: String, primary: Boolean) = Button(this).apply {
        text = textValue
        textSize = 11f
        isAllCaps = false
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (primary) colors.white else colors.ink)
        background = rounded(if (primary) colors.coral else colors.white, 8, if (primary) colors.coral else colors.line)
        minHeight = dp(42)
        stateListAnimator = null
    }

    private fun pill(textValue: String, bg: Int, fg: Int) = TextView(this).apply {
        text = textValue
        textSize = 8f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(fg)
        setPadding(dp(8), dp(5), dp(8), dp(5))
        background = rounded(bg, 5)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
