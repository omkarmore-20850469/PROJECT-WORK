using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace RescueNet.Api.Hubs;

/// <summary>Events: ReceiveNewSignals, SignalUpdated, TeamUpdated, ActivityAdded</summary>
[Authorize]
public sealed class RescueHub : Hub { }
