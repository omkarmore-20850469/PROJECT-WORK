using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using RescueNet.Api.Data;
using RescueNet.Api.DTOs;
using RescueNet.Api.Hubs;
using RescueNet.Api.Models;
using RescueNet.Api.Services;

namespace RescueNet.Api.Controllers;

[ApiController, Authorize, Route("api/signals")]
public sealed class SignalsController(AppDbContext db, IngestService ingest, ActivityService activity, IHubContext<RescueHub> hub) : ControllerBase
{
    /// <summary>All incidents ordered by AI priority, then age (oldest first).</summary>
    [HttpGet]
    public async Task<IActionResult> List() =>
        Ok(await db.Signals.OrderByDescending(s => s.Priority).ThenBy(s => s.CreatedAtMs).Take(1000).ToListAsync());

    [HttpGet("stats")]
    public async Task<IActionResult> Stats()
    {
        var open = db.Signals.Where(s => s.Status != "Rescued");
        return Ok(new
        {
            open = await open.CountAsync(),
            critical = await open.CountAsync(s => s.RiskScore == 4),
            pending = await open.CountAsync(s => s.Status == "Pending"),
            rescued = await db.Signals.CountAsync(s => s.Status == "Rescued"),
            people = await open.SumAsync(s => (int?)s.People) ?? 0
        });
    }

    /// <summary>Direct SOS from a phone that currently has internet (no mesh hops needed).</summary>
    [HttpPost]
    public async Task<IActionResult> Create(CreateSignalRequest req)
    {
        if (req.Latitude is < -90 or > 90 || req.Longitude is < -180 or > 180) return BadRequest(new { message = "Coordinates are outside the valid range." });
        if (req.People is < 1 or > 1000) return BadRequest(new { message = "People must be between 1 and 1000." });
        if ((req.Note?.Length ?? 0) > 280) return BadRequest(new { message = "Note must be 280 characters or fewer." });
        var citizenId = string.IsNullOrWhiteSpace(req.CitizenId) ? $"CIT-{Random.Shared.Next(1000, 9999)}" : req.CitizenId.Trim();
        if (citizenId.Length > 64) return BadRequest(new { message = "CitizenId must be 64 characters or fewer." });

        var triage = Triage.Analyze(req.Note, req.Category, req.People);
        var createdAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var packet = new MeshPacket(MeshId.Compute(citizenId, createdAt), citizenId, req.Latitude, req.Longitude,
            req.RiskScore is >= 1 and <= 4 ? req.RiskScore.Value : triage.RiskScore, req.People, req.Note, createdAt,
            [citizenId.Length > 8 ? citizenId[^8..] : citizenId], triage.Category, triage.Priority, req.BatteryPct);
        var result = await ingest.IngestAsync([packet], "DIRECT");
        if (result.NewAlerts == 0) return Conflict(new { message = "The SOS could not be stored (duplicate or invalid)." });
        return Created($"/api/signals/{packet.MessageId}", await db.Signals.FindAsync(packet.MessageId));
    }

    [HttpPost("{id}/dispatch")]
    public async Task<IActionResult> Dispatch(string id, DispatchRequest? req)
    {
        var signal = await db.Signals.FindAsync(id);
        if (signal is null) return NotFound(new { message = "Signal not found." });
        if (signal.Status != "Pending") return Conflict(new { message = "Signal is already dispatched or rescued." });

        var free = await db.Teams.Where(t => t.Status == "Available").ToListAsync();
        var team = req?.TeamId is int tid
            ? free.FirstOrDefault(t => t.Id == tid)
            : free.OrderBy(t => Geo.Km(t.Latitude, t.Longitude, signal.Latitude, signal.Longitude)).FirstOrDefault();
        if (team is null) return Conflict(new { message = "No available rescue team." });

        team.Status = "Busy";
        signal.Status = "Dispatched";
        signal.AssignedTeamId = team.Id;
        signal.AssignedTeamName = team.Name;
        await db.SaveChangesAsync();
        await hub.Clients.All.SendAsync("SignalUpdated", signal);
        await hub.Clients.All.SendAsync("TeamUpdated", team);
        await activity.LogAsync("info", $"{team.Name} dispatched", $"{signal.CitizenId} · {signal.Category} · priority {signal.Priority}.");
        return Ok(signal);
    }

    [HttpPost("{id}/rescued")]
    public async Task<IActionResult> Rescued(string id)
    {
        var signal = await db.Signals.FindAsync(id);
        if (signal is null) return NotFound(new { message = "Signal not found." });
        signal.Status = "Rescued";
        RescueTeam? released = null;
        if (signal.AssignedTeamId is int tid && await db.Teams.FindAsync(tid) is { } team) { team.Status = "Available"; released = team; }
        await db.SaveChangesAsync();
        await hub.Clients.All.SendAsync("SignalUpdated", signal);
        if (released is not null) await hub.Clients.All.SendAsync("TeamUpdated", released);
        await activity.LogAsync("success", $"{signal.CitizenId} marked rescued", released is null ? "Closed without an assigned team." : $"{released.Name} is available again.");
        return Ok(signal);
    }
}
