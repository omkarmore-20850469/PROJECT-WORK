using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RescueNet.Api.Data;

namespace RescueNet.Api.Controllers;

[ApiController, Authorize]
public sealed class TeamsController(AppDbContext db) : ControllerBase
{
    [HttpGet("api/teams")] public async Task<IActionResult> Teams() => Ok(await db.Teams.OrderBy(t => t.Name).ToListAsync());
    [HttpGet("api/zones")] public async Task<IActionResult> Zones() => Ok(await db.Zones.OrderBy(z => z.Type).ThenBy(z => z.Name).ToListAsync());
    [HttpGet("api/activity")] public async Task<IActionResult> Activity() => Ok(await db.Activity.OrderByDescending(a => a.TimeMs).Take(100).ToListAsync());
}
