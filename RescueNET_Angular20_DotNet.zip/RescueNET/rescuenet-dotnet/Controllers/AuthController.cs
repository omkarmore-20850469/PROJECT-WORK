using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RescueNet.Api.Data;
using RescueNet.Api.DTOs;
using RescueNet.Api.Models;
using RescueNet.Api.Services;

namespace RescueNet.Api.Controllers;

[ApiController, Route("api/[controller]")]
public sealed class AuthController(AppDbContext db, TokenService tokens, ActivityService activity) : ControllerBase
{
    [HttpPost("register"), AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(u => u.Email == email))
            return Conflict(new { message = "An account with this email already exists." });
        var role = string.Equals(request.Role, "Responder", StringComparison.OrdinalIgnoreCase) ? "Responder" : "Citizen";
        var user = new User { DisplayName = request.DisplayName.Trim(), Email = email, Role = role, PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password) };
        db.Users.Add(user);
        await db.SaveChangesAsync();
        await activity.LogAsync("info", "New account created", $"{user.DisplayName} joined RescueNET as {user.Role}.");
        return Ok(new AuthResponse(tokens.Create(user), user.Email, user.DisplayName, user.Role));
    }

    [HttpPost("login"), AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await db.Users.SingleOrDefaultAsync(u => u.Email == email);
        if (user is null || !BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
            return Unauthorized(new { message = "Email or password is incorrect." });
        return Ok(new AuthResponse(tokens.Create(user), user.Email, user.DisplayName, user.Role));
    }

    [HttpGet("me"), Authorize]
    public async Task<IActionResult> Me()
    {
        if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id)) return Unauthorized();
        var user = await db.Users.FindAsync(id);
        return user is null ? NotFound() : Ok(new { user.Id, user.Email, user.DisplayName, user.Role });
    }
}
