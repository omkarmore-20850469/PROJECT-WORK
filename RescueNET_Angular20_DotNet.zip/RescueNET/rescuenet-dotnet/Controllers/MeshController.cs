using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RescueNet.Api.Data;
using RescueNet.Api.DTOs;
using RescueNet.Api.Services;

namespace RescueNet.Api.Controllers;

[ApiController]
public sealed class MeshController(AppDbContext db, IngestService ingest, IConfiguration config) : ControllerBase
{
    /// <summary>Gateway upload for real phones / base stations. Authenticated with X-Gateway-Key.</summary>
    [HttpPost("api/mesh-ingest/sync-payload"), AllowAnonymous]
    public async Task<IActionResult> SyncPayload([FromBody] List<MeshPacket> packets)
    {
        var expected = Encoding.UTF8.GetBytes(config["Gateway:ApiKey"] ?? "dev-gateway-key");
        var provided = Encoding.UTF8.GetBytes(Request.Headers["X-Gateway-Key"].ToString());
        if (!CryptographicOperations.FixedTimeEquals(provided, expected)) return Unauthorized(new { message = "Invalid gateway key." });
        if (packets.Count is 0 or > 500) return BadRequest(new { message = "Send between 1 and 500 packets per upload." });
        var gatewayId = Request.Headers["X-Gateway-Id"].FirstOrDefault() ?? "unknown";
        return Ok(await ingest.IngestAsync(packets, gatewayId[..Math.Min(gatewayId.Length, 24)]));
    }

    /// <summary>Upload from the web app's own gateway node (a signed-in operator device that has internet).</summary>
    [HttpPost("api/mesh/relay-upload"), Authorize]
    public async Task<IActionResult> RelayUpload(RelayUploadRequest req)
    {
        if (req.Packets.Count is 0 or > 500) return BadRequest(new { message = "Send between 1 and 500 packets per upload." });
        var label = string.IsNullOrWhiteSpace(req.GatewayLabel) ? "WEB-GW" : req.GatewayLabel.Trim();
        return Ok(await ingest.IngestAsync(req.Packets, label[..Math.Min(label.Length, 24)]));
    }

    /// <summary>Mesh topology reconstructed from the hop paths of stored packets.</summary>
    [HttpGet("api/mesh/topology"), Authorize]
    public async Task<IActionResult> Topology()
    {
        var rows = await db.Signals.OrderByDescending(s => s.ReceivedAtMs).Take(300).Select(s => new { s.HopPath, s.RiskScore }).ToListAsync();
        var nodes = new Dictionary<string, (string Kind, int Packets)>();
        var edges = new Dictionary<(string, string), int>();
        foreach (var r in rows)
        {
            var hops = r.HopPath.Split(" → ", StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            for (var i = 0; i < hops.Length; i++)
            {
                var kind = hops[i].StartsWith("Gateway(") ? "gateway" : i == 0 ? "origin" : "relay";
                nodes[hops[i]] = (kind, nodes.TryGetValue(hops[i], out var n) ? n.Packets + 1 : 1);
                if (i > 0) edges[(hops[i - 1], hops[i])] = edges.GetValueOrDefault((hops[i - 1], hops[i])) + 1;
            }
        }
        return Ok(new
        {
            nodes = nodes.Select(kv => new { id = kv.Key, kind = kv.Value.Kind, packets = kv.Value.Packets }),
            edges = edges.Select(kv => new { from = kv.Key.Item1, to = kv.Key.Item2, packets = kv.Value })
        });
    }

    [HttpGet("api/mesh/gateways"), Authorize]
    public async Task<IActionResult> Gateways() =>
        Ok(await db.Signals.GroupBy(s => s.GatewayId)
            .Select(g => new { gatewayId = g.Key, packets = g.Count(), lastSeenMs = g.Max(s => s.ReceivedAtMs), avgHops = g.Average(s => s.HopCount) })
            .OrderByDescending(g => g.lastSeenMs).ToListAsync());

    [HttpPost("api/triage/analyze"), Authorize]
    public IActionResult Analyze(TriageRequest req) => Ok(Triage.Analyze(req.Text, req.Category, req.People));

    [HttpGet("api/health"), AllowAnonymous]
    public async Task<IActionResult> Health() => Ok(new
    {
        status = "ok", service = "RescueNET API", serverTime = DateTimeOffset.UtcNow,
        openSignals = await db.Signals.CountAsync(s => s.Status != "Rescued"),
        availableTeams = await db.Teams.CountAsync(t => t.Status == "Available")
    });
}
