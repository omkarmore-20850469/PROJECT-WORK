using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RescueNet.Api.DTOs;
using RescueNet.Api.Services;

namespace RescueNet.Api.Controllers;

/// <summary>Development-only gateway simulator (disabled unless Dev:EnableSimulator is true).</summary>
[ApiController, Authorize, Route("api/dev")]
public sealed class DevController(IngestService ingest, IConfiguration config) : ControllerBase
{
    private static readonly string[] Relays = ["A-17", "B-04", "C-92", "D-31", "E-58"];
    private static readonly string[] Notes =
    [
        "I am trapped on the 3rd floor. My grandmother can't walk. Water is entering the building.",
        "Water is rising in our lane, elderly neighbour needs help",
        "Injured leg, cannot walk, bleeding a little",
        "Building partially collapsed next to the station",
        "Family of 4, safe for now at the school",
        "Need medicines and drinking water",
        "Gas leak smell near the market, unsafe",
        "Smoke from the electrical room, people inside"
    ];

    [HttpPost("simulate")]
    public async Task<IActionResult> Simulate(int? count)
    {
        if (!config.GetValue<bool>("Dev:EnableSimulator")) return NotFound();
        var rnd = new Random();
        var n = Math.Clamp(count ?? 15, 1, 200);
        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var packets = Enumerable.Range(0, n).Select(_ =>
        {
            var cid = $"citizen-{rnd.Next(1000, 9999)}";
            var ts = now - rnd.Next(0, 3_600_000);
            var note = Notes[rnd.Next(Notes.Length)];
            var people = rnd.Next(1, 6);
            var t = Triage.Analyze(note, null, people);
            var hops = new List<string> { cid[^4..] };
            hops.AddRange(Enumerable.Range(0, rnd.Next(1, 5)).Select(_ => Relays[rnd.Next(Relays.Length)]));
            return new MeshPacket(MeshId.Compute(cid, ts), cid, 19.076 + (rnd.NextDouble() - .5) * .16, 72.877 + (rnd.NextDouble() - .5) * .16,
                t.RiskScore, people, note, ts, hops, t.Category, t.Priority, rnd.Next(8, 96));
        }).ToList();
        packets.AddRange(packets.Take(n / 3).ToList()); // the same SOS arriving through a second route
        return Ok(await ingest.IngestAsync(packets, "SIM-GW"));
    }
}
