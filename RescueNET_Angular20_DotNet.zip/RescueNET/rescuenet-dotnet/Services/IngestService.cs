using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using RescueNet.Api.Data;
using RescueNet.Api.DTOs;
using RescueNet.Api.Hubs;
using RescueNet.Api.Models;

namespace RescueNet.Api.Services;

public sealed class IngestService(AppDbContext db, IHubContext<RescueHub> hub, ActivityService activity)
{
    public async Task<IngestResult> IngestAsync(List<MeshPacket> packets, string gatewayId)
    {
        var rejected = 0;
        var valid = new Dictionary<string, MeshPacket>();
        foreach (var p in packets)
        {
            if (!IsValid(p)) { rejected++; continue; }
            valid.TryAdd(p.MessageId, p); // the same SOS arriving by two routes inside one upload collapses here
        }

        var ids = valid.Keys.ToList();
        var known = (await db.Signals.Where(s => ids.Contains(s.MessageId)).Select(s => s.MessageId).ToListAsync()).ToHashSet();
        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        var fresh = valid.Values.Where(p => !known.Contains(p.MessageId)).Select(p =>
        {
            var triage = Triage.Analyze(p.Note, p.Category, p.People);
            var hops = (p.HopPath ?? []).Where(h => !string.IsNullOrWhiteSpace(h)).Select(h => h.Trim()[..Math.Min(h.Trim().Length, 32)]).Take(20).ToList();
            return new DistressSignal
            {
                MessageId = p.MessageId, CitizenId = p.CitizenId,
                Latitude = p.Latitude, Longitude = p.Longitude,
                RiskScore = p.RiskScore, Priority = p.Priority ?? triage.Priority,
                Category = string.IsNullOrWhiteSpace(p.Category) ? triage.Category : p.Category!,
                People = p.People, Note = p.Note?.Trim(), TriageSummary = triage.Summary,
                MobilityIssue = triage.MobilityIssue, BatteryPct = p.BatteryPct,
                CreatedAtMs = p.CreatedAtMs, ReceivedAtMs = now,
                HopCount = hops.Count,
                HopPath = string.Join(" → ", hops.Append($"Gateway({gatewayId})")),
                GatewayId = gatewayId
            };
        }).ToList();

        if (fresh.Count > 0)
        {
            db.Signals.AddRange(fresh);
            await db.SaveChangesAsync();
            await hub.Clients.All.SendAsync("ReceiveNewSignals", fresh);
            var critical = fresh.Count(s => s.RiskScore == 4);
            await activity.LogAsync(critical > 0 ? "critical" : "info",
                $"{fresh.Count} new SOS packet{(fresh.Count == 1 ? "" : "s")} via {gatewayId}",
                $"{critical} critical · {fresh.Sum(s => s.HopCount)} relay hops · {packets.Count - rejected - fresh.Count} duplicate(s) dropped.");
        }
        return new IngestResult(packets.Count, fresh.Count, packets.Count - rejected - fresh.Count, rejected);
    }

    private static bool IsValid(MeshPacket p)
    {
        var maxTs = DateTimeOffset.UtcNow.AddMinutes(5).ToUnixTimeMilliseconds();
        return !string.IsNullOrWhiteSpace(p.CitizenId) && p.CitizenId.Length <= 64
            && p.MessageId == MeshId.Compute(p.CitizenId, p.CreatedAtMs)      // tamper / forged-id check
            && p.RiskScore is >= 1 and <= 4
            && p.Latitude is >= -90 and <= 90 && p.Longitude is >= -180 and <= 180
            && p.People is >= 1 and <= 1000
            && (p.Note?.Length ?? 0) <= 280
            && (p.Category?.Length ?? 0) <= 24
            && (p.Priority is null or (>= 0 and <= 100))
            && (p.BatteryPct is null or (>= 0 and <= 100))
            && p.CreatedAtMs > 1_577_836_800_000 && p.CreatedAtMs <= maxTs;
    }
}
