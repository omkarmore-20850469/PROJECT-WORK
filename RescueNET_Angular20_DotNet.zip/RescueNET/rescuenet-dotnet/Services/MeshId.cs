using System.Security.Cryptography;
using System.Text;

namespace RescueNet.Api.Services;

public static class MeshId
{
    /// <summary>MessageId = lowercase hex SHA-256 of "citizenId|createdAtMs". Phones and server use the same rule.</summary>
    public static string Compute(string citizenId, long createdAtMs) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"{citizenId}|{createdAtMs}"))).ToLowerInvariant();
}
