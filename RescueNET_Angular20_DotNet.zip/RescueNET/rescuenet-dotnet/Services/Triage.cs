namespace RescueNet.Api.Services;

public sealed record TriageResult(string Category, string Severity, int Priority, int RiskScore,
    int People, bool MobilityIssue, string[] Hazards, string Summary);

/// <summary>
/// Deterministic, explainable emergency triage. Runs on the phone (TypeScript mirror) so it works offline,
/// and again on the server so the cloud never trusts a client-supplied score blindly.
/// </summary>
public static class Triage
{
    private static readonly (string Category, int Base, string[] Keywords)[] Rules =
    [
        ("Collapse", 100, new[] { "collapse", "collapsed", "rubble", "debris", "building fell", "caved" }),
        ("Medical",   95, new[] { "bleeding", "injured", "injury", "unconscious", "heart", "breathing", "pregnant", "fracture", "broken", "medical", "insulin", "ambulance", "faint" }),
        ("Fire",      92, new[] { "fire", "smoke", "burning", "blaze", "explosion" }),
        ("Trapped",   90, new[] { "trapped", "stuck", "cannot get out", "can't get out", "locked in", "pinned" }),
        ("Flood",     85, new[] { "flood", "water entering", "water rising", "rising water", "submerged", "drown", "knee level", "waist level", "water is entering", "water level" }),
        ("Warning",   60, new[] { "warning", "danger", "hazard", "live wire", "gas leak", "landslide", "unsafe" }),
        ("Supplies",  50, new[] { "food", "hungry", "drinking water", "supplies", "medicines", "medicine", "thirst", "blanket", "need water" }),
        ("Safe",      20, new[] { "i am safe", "i'm safe", "we are safe", "safe now", "all ok", "no injuries" }),
        ("Noise",      5, new[] { "wifi", "wi-fi", "internet", "recharge", "data pack" }),
    ];

    private static readonly string[] MobilityWords =
        ["can't walk", "cannot walk", "cant walk", "wheelchair", "elderly", "grandmother", "grandfather",
         "old man", "old woman", "child", "children", "baby", "infant", "disabled", "pregnant", "bedridden"];

    private static readonly (string Hazard, string[] Keywords)[] HazardRules =
    [
        ("Flood risk", new[] { "water", "flood", "rising", "submerged" }),
        ("Structural risk", new[] { "collapse", "crack", "rubble", "building" }),
        ("Fire / smoke", new[] { "fire", "smoke", "burning" }),
        ("Medical need", new[] { "bleeding", "injured", "unconscious", "medicine", "insulin", "heart", "breathing" }),
        ("Mobility limited", new[] { "can't walk", "cannot walk", "wheelchair", "elderly", "grandmother", "grandfather", "bedridden" }),
    ];

    public static TriageResult Analyze(string? text, string? category, int? people)
    {
        var t = (text ?? "").ToLowerInvariant();
        string? bestCategory = null; var bestBase = -1;
        foreach (var (cat, baseScore, kws) in Rules)
            if (kws.Any(k => t.Contains(k)) && baseScore > bestBase) { bestBase = baseScore; bestCategory = cat; }

        var picked = Rules.FirstOrDefault(r => string.Equals(r.Category, category, StringComparison.OrdinalIgnoreCase));
        if (picked.Category is not null && picked.Base > bestBase) { bestBase = picked.Base; bestCategory = picked.Category; }
        if (bestCategory is null) { bestCategory = "General"; bestBase = 40; }

        var count = Math.Clamp(people ?? 1, 1, 1000);
        var mobility = MobilityWords.Any(w => t.Contains(w));
        var hazards = HazardRules.Where(h => h.Keywords.Any(k => t.Contains(k))).Select(h => h.Hazard).ToList();
        if (bestCategory == "Flood" && !hazards.Contains("Flood risk")) hazards.Add("Flood risk");

        var score = bestBase + Math.Min(8, (count - 1) * 2) + (mobility ? 5 : 0);
        if (bestCategory is "Safe" or "Noise") score = Math.Min(score, 25);
        score = Math.Clamp(score, 0, 100);

        var risk = score >= 90 ? 4 : score >= 70 ? 3 : score >= 40 ? 2 : 1;
        var severity = risk switch { 4 => "Critical", 3 => "High", 2 => "Moderate", _ => "Low" };
        var summary = $"{severity} · {bestCategory} · {count} {(count == 1 ? "person" : "people")}"
                      + (mobility ? " · mobility limited" : "")
                      + (hazards.Count > 0 ? $" · {string.Join(", ", hazards).ToLowerInvariant()}" : "");
        return new TriageResult(bestCategory, severity, score, risk, count, mobility, hazards.ToArray(), summary);
    }
}
