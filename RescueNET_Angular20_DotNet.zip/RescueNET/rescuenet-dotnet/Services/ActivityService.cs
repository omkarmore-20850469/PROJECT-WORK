using Microsoft.AspNetCore.SignalR;
using RescueNet.Api.Data;
using RescueNet.Api.Hubs;
using RescueNet.Api.Models;

namespace RescueNet.Api.Services;

public sealed class ActivityService(AppDbContext db, IHubContext<RescueHub> hub)
{
    public async Task LogAsync(string kind, string title, string detail)
    {
        var entry = new ActivityLog { TimeMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(), Kind = kind, Title = title, Detail = detail };
        db.Activity.Add(entry);
        await db.SaveChangesAsync();
        await hub.Clients.All.SendAsync("ActivityAdded", entry);
    }
}
