namespace RescueNet.Api.Services;

public static class Geo
{
    public static double Km(double la1, double lo1, double la2, double lo2)
    {
        const double R = 6371;
        static double Rad(double d) => d * Math.PI / 180;
        var dLa = Rad(la2 - la1); var dLo = Rad(lo2 - lo1);
        var a = Math.Sin(dLa / 2) * Math.Sin(dLa / 2) + Math.Cos(Rad(la1)) * Math.Cos(Rad(la2)) * Math.Sin(dLo / 2) * Math.Sin(dLo / 2);
        return 2 * R * Math.Asin(Math.Sqrt(a));
    }
}
