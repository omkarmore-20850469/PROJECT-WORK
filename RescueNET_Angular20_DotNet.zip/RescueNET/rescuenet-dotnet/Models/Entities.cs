using System.ComponentModel.DataAnnotations;

namespace RescueNet.Api.Models;

public sealed class User
{
    public int Id { get; set; }
    [MaxLength(80)] public string DisplayName { get; set; } = "";
    [MaxLength(254)] public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    [MaxLength(16)] public string Role { get; set; } = "Citizen"; // Citizen | Responder
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>An SOS / status packet that reached the cloud (directly or through the Bluetooth mesh).</summary>
public sealed class DistressSignal
{
    [Key] public string MessageId { get; set; } = "";
    public string CitizenId { get; set; } = "";
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public int RiskScore { get; set; }              // 1 Low, 2 Medium, 3 High, 4 Critical
    public int Priority { get; set; }               // 0..100 from the AI triage engine
    public string Category { get; set; } = "General";
    public int People { get; set; } = 1;
    public string? Note { get; set; }
    public string? TriageSummary { get; set; }
    public bool MobilityIssue { get; set; }
    public int? BatteryPct { get; set; }
    public string Status { get; set; } = "Pending"; // Pending | Dispatched | Rescued
    public long CreatedAtMs { get; set; }
    public long ReceivedAtMs { get; set; }
    public string HopPath { get; set; } = "";       // "A → B → Gateway(G1)"
    public int HopCount { get; set; }
    public string GatewayId { get; set; } = "";
    public int? AssignedTeamId { get; set; }
    public string? AssignedTeamName { get; set; }
}

public sealed class RescueTeam
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Type { get; set; } = "";
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string Status { get; set; } = "Available"; // Available | Busy
}

/// <summary>Hospitals, water points, shelters, rescue bases and dead zones shown on the survival map.</summary>
public sealed class MapZone
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Type { get; set; } = "";   // Hospital | Water | Shelter | Rescue | DeadZone
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public int RadiusM { get; set; }
    public string Status { get; set; } = "Open"; // Open | Flooded | NoPower | Offline
    public string? Detail { get; set; }
    public int MeshDevices { get; set; }
}

public sealed class ActivityLog
{
    public int Id { get; set; }
    public long TimeMs { get; set; }
    public string Kind { get; set; } = "info"; // info | success | warning | critical
    public string Title { get; set; } = "";
    public string Detail { get; set; } = "";
}
