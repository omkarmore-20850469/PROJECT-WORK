using System.Text;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using RescueNet.Api.Data;
using RescueNet.Api.Hubs;
using RescueNet.Api.Models;
using RescueNet.Api.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers().AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSignalR();
builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));

var jwtKey = builder.Configuration["Jwt:Key"] ?? throw new InvalidOperationException("JWT key is not configured.");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o =>
{
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true, ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"], ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)), ClockSkew = TimeSpan.FromSeconds(30)
    };
    // SignalR (WebSocket) cannot send an Authorization header, so it passes the token in the query string.
    o.Events = new JwtBearerEvents
    {
        OnMessageReceived = ctx =>
        {
            var token = ctx.Request.Query["access_token"];
            if (!string.IsNullOrEmpty(token) && ctx.HttpContext.Request.Path.StartsWithSegments("/rescueHub")) ctx.Token = token;
            return Task.CompletedTask;
        }
    };
});
builder.Services.AddAuthorization();
builder.Services.AddScoped<TokenService>();
builder.Services.AddScoped<ActivityService>();
builder.Services.AddScoped<IngestService>();
builder.Services.AddCors(o => o.AddPolicy("Angular", p => p
    .WithOrigins("http://localhost:4200", "http://127.0.0.1:4200", "https://localhost:4200")
    .AllowAnyHeader().AllowAnyMethod().AllowCredentials()));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    await db.Database.EnsureCreatedAsync();
    await Seed.RunAsync(db, builder.Configuration);
}

app.UseMiddleware<ErrorHandlingMiddleware>();
app.UseCors("Angular");
app.UseAuthentication();
app.UseAuthorization();
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.MapHub<RescueHub>("/rescueHub");
app.MapGet("/health", () => Results.Ok(new { status = "healthy", service = "RescueNET API" }));
app.Run();

static class Seed
{
    public static async Task RunAsync(AppDbContext db, IConfiguration config)
    {
        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        if (config.GetValue<bool>("Dev:SeedDemoUser") && !await db.Users.AnyAsync())
            db.Users.Add(new User { DisplayName = "Demo Responder", Email = "demo@rescuenet.app", Role = "Responder", PasswordHash = BCrypt.Net.BCrypt.HashPassword("Demo@1234") });

        if (!await db.Teams.AnyAsync())
            db.Teams.AddRange(
                new RescueTeam { Name = "NDRF Unit Alpha", Type = "Search & rescue", Latitude = 19.0176, Longitude = 72.8562 },
                new RescueTeam { Name = "Red Cross Medical 1", Type = "Medical", Latitude = 19.1136, Longitude = 72.8697, Status = "Busy" },
                new RescueTeam { Name = "Coast Guard Boat Team", Type = "Water rescue", Latitude = 18.9220, Longitude = 72.8347 },
                new RescueTeam { Name = "Fire Brigade Rescue 3", Type = "Fire & collapse", Latitude = 19.0760, Longitude = 72.8777 },
                new RescueTeam { Name = "Thane Volunteers", Type = "Volunteer support", Latitude = 19.2183, Longitude = 72.9781 });

        if (!await db.Zones.AnyAsync())
            db.Zones.AddRange(
                new MapZone { Name = "KEM Hospital", Type = "Hospital", Latitude = 19.0023, Longitude = 72.8416, Status = "Open", Detail = "Trauma ward accepting patients" },
                new MapZone { Name = "Sion Hospital", Type = "Hospital", Latitude = 19.0390, Longitude = 72.8619, Status = "NoPower", Detail = "On generator backup" },
                new MapZone { Name = "Lilavati Hospital", Type = "Hospital", Latitude = 19.0509, Longitude = 72.8294, Status = "Flooded", Detail = "Ground floor flooded" },
                new MapZone { Name = "Drinking water point · Matunga", Type = "Water", Latitude = 19.0270, Longitude = 72.8570, Status = "Open", Detail = "Tanker refilled 20 min ago" },
                new MapZone { Name = "Drinking water point · Bandra", Type = "Water", Latitude = 19.0596, Longitude = 72.8295, Status = "Open", Detail = "Bottled water distribution" },
                new MapZone { Name = "Dharavi municipal school shelter", Type = "Shelter", Latitude = 19.0430, Longitude = 72.8553, Status = "Open", Detail = "Capacity 400 · 260 sheltered" },
                new MapZone { Name = "Kurla community hall shelter", Type = "Shelter", Latitude = 19.0668, Longitude = 72.8790, Status = "Open", Detail = "Capacity 250 · 90 sheltered" },
                new MapZone { Name = "NDRF forward base", Type = "Rescue", Latitude = 19.0560, Longitude = 72.8490, Status = "Open", Detail = "3 boats · 2 rescue teams" },
                new MapZone { Name = "Kurla dead zone", Type = "DeadZone", Latitude = 19.0726, Longitude = 72.8845, RadiusM = 1500, Status = "Offline", Detail = "No cellular or Wi-Fi internet", MeshDevices = 312 },
                new MapZone { Name = "Dharavi dead zone", Type = "DeadZone", Latitude = 19.0422, Longitude = 72.8554, RadiusM = 900, Status = "Offline", Detail = "Tower outage", MeshDevices = 148 });

        if (!await db.Signals.AnyAsync())
        {
            DistressSignal Make(string id, string cid, double lat, double lon, string note, string? cat, int people, string status, int createdAgoMin, int recvAgoMin, string path, string gw, int? batt = null, int? teamId = null, string? teamName = null)
            {
                var t = Triage.Analyze(note, cat, people);
                var hops = path.Split(" → ").Length - 1;
                return new DistressSignal
                {
                    MessageId = id, CitizenId = cid, Latitude = lat, Longitude = lon, Note = note, People = people, Status = status,
                    Category = t.Category, Priority = t.Priority, RiskScore = t.RiskScore, TriageSummary = t.Summary, MobilityIssue = t.MobilityIssue,
                    BatteryPct = batt, CreatedAtMs = now - createdAgoMin * 60_000L, ReceivedAtMs = now - recvAgoMin * 60_000L,
                    HopPath = path, HopCount = hops, GatewayId = gw, AssignedTeamId = teamId, AssignedTeamName = teamName
                };
            }

            db.Signals.AddRange(
                Make("DEMO-RM-1042", "CIT-1042", 19.0760, 72.8777, "I am trapped on the 3rd floor. My grandmother can't walk. Water is entering the building.", null, 2, "Pending", 12, 8, "1042 → B-04 → F-12 → Gateway(GW-MUM-01)", "GW-MUM-01", 41),
                Make("DEMO-RM-2091", "CIT-2091", 19.0822, 72.8811, "Injured adult, bleeding from the leg, needs medical assistance", null, 1, "Dispatched", 24, 20, "2091 → Gateway(GW-MUM-01)", "GW-MUM-01", 63, 2, "Red Cross Medical 1"),
                Make("DEMO-RM-3370", "CIT-3370", 19.0680, 72.8690, "Family of three waiting at a community shelter, need food and drinking water", null, 3, "Pending", 31, 28, "3370 → E-22 → F-12 → Gateway(GW-MUM-02)", "GW-MUM-02", 77),
                Make("DEMO-RM-4418", "CIT-4418", 19.0910, 72.8610, "Older adult requires evacuation support, cannot walk", null, 1, "Pending", 43, 39, "4418 → H-08 → Gateway(GW-MUM-02)", "GW-MUM-02", 22),
                Make("DEMO-RM-5001", "CIT-5001", 19.0735, 72.8838, "Water is rising, knee level on our street", null, 2, "Pending", 18, 14, "5001 → C-92 → Gateway(GW-MUM-01)", "GW-MUM-01", 55),
                Make("DEMO-RM-5002", "CIT-5002", 19.0722, 72.8852, "Flood water rising near the bus depot, knee level", null, 1, "Pending", 16, 12, "5002 → A-17 → C-92 → Gateway(GW-MUM-01)", "GW-MUM-01", 48),
                Make("DEMO-RM-5003", "CIT-5003", 19.0711, 72.8830, "Street flooded, water level above knee", null, 4, "Pending", 15, 11, "5003 → D-31 → Gateway(GW-MUM-01)", "GW-MUM-01", 36),
                Make("DEMO-RM-5004", "CIT-5004", 19.0744, 72.8861, "Water is entering ground floor shops, waist level", null, 1, "Pending", 9, 6, "5004 → C-92 → Gateway(GW-MUM-01)", "GW-MUM-01", 69),
                Make("DEMO-RM-6001", "CIT-6001", 19.0455, 72.8561, "I'm safe, reached the school shelter", null, 1, "Pending", 50, 44, "6001 → Gateway(GW-MUM-02)", "GW-MUM-02", 80));
        }

        if (!await db.Activity.AnyAsync())
            db.Activity.AddRange(
                new ActivityLog { TimeMs = now - 90_000, Kind = "info", Title = "Command center initialized", Detail = "RescueNET API started; waiting for gateway uploads." },
                new ActivityLog { TimeMs = now - 60_000, Kind = "success", Title = "Gateway GW-MUM-01 online", Detail = "Gateway reachable over Wi-Fi uplink." });

        await db.SaveChangesAsync();
    }
}
