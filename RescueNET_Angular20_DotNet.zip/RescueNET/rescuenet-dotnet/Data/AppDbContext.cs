using Microsoft.EntityFrameworkCore;
using RescueNet.Api.Models;

namespace RescueNet.Api.Data;

public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<DistressSignal> Signals => Set<DistressSignal>();
    public DbSet<RescueTeam> Teams => Set<RescueTeam>();
    public DbSet<MapZone> Zones => Set<MapZone>();
    public DbSet<ActivityLog> Activity => Set<ActivityLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>().HasIndex(x => x.Email).IsUnique();
        b.Entity<DistressSignal>().HasIndex(x => x.Status);
        b.Entity<DistressSignal>().HasIndex(x => x.Priority);
    }
}
