using System.ComponentModel.DataAnnotations;

namespace RescueNet.Api.DTOs;

public sealed record RegisterRequest(
    [Required, MinLength(2), MaxLength(80)] string DisplayName,
    [Required, EmailAddress, MaxLength(254)] string Email,
    [Required, MinLength(8), MaxLength(100)] string Password,
    string? Role);
public sealed record LoginRequest([Required, EmailAddress] string Email, [Required, MinLength(1)] string Password);
public sealed record AuthResponse(string Token, string Email, string DisplayName, string Role);

/// <summary>Packet exactly as it travels over the Bluetooth mesh and is uploaded by a gateway.</summary>
public sealed record MeshPacket(
    string MessageId, string CitizenId, double Latitude, double Longitude,
    int RiskScore, int People, string? Note, long CreatedAtMs, List<string>? HopPath,
    string? Category = null, int? Priority = null, int? BatteryPct = null);

public sealed record CreateSignalRequest(
    string? CitizenId, double Latitude, double Longitude, int? RiskScore, int People,
    string? Note, string? Category, int? BatteryPct);
public sealed record DispatchRequest(int? TeamId);
public sealed record IngestResult(int Processed, int NewAlerts, int Duplicates, int Rejected);
public sealed record TriageRequest(string? Text, string? Category, int? People);
public sealed record RelayUploadRequest(string GatewayLabel, List<MeshPacket> Packets);
