# RescueNET — phone-to-phone emergency mesh (Angular 20 + ASP.NET Core)

Same UI system as **FitTrack** (sidebar shell, hero banner, stat cards, panels, split auth screens, purple/navy theme), rebuilt for the **RescueMesh** idea:
*when the internet goes down, nearby phones become the network.*

## What is in the box
| Folder | What it is |
|---|---|
| `rescuenet-angular20/` | Angular 20 app (standalone components, signals, FitTrack styling) |
| `rescuenet-dotnet/` | ASP.NET Core 8 API: JWT auth, EF Core + SQLite, SignalR, AI triage, mesh ingest |
| `mobile-android/` | Your original Android BLE starter (unchanged — see its README for its limits) |
| `docs/BLE-PROTOCOL.md` | GATT + packet contract shared by web and native clients |

## Screens
1. **Sign in / Create account** — FitTrack auth layout; Citizen or Responder role. Demo user is seeded: `demo@rescuenet.app` / `Demo@1234`.
2. **Overview** — "MESH ACTIVE · n devices nearby", live stats, priority queue, nearby safe zones, dead-zone and flood-zone insight.
3. **Send SOS** — 8 emergency types, message, people, GPS, **live on-device AI triage** (priority 0–100), **hold 2 s to send**, then a live delivery tracker (stored → relayed → gateway → command center).
4. **Incidents** — ranked command-center table with search/risk/status filters, detail panel with the **exact mesh path**, dispatch nearest team, mark rescued.
5. **Mesh network** — interactive **3D** visualisation: nodes, radio links, glowing packet pulses; add/drop phones, simulate an internet outage, live packet log, node table, and **real Bluetooth** device connection.
6. **Survival map** — Leaflet map: SOS reports, AI-clustered **flood zones** with confidence, **dead zones** with active mesh device counts, hospitals/water/shelters, rescue teams.
7. **Rescue teams** — readiness, nearest-priority dispatch, active missions.
8. **Activity & settings** — device identity, local outbox, gateway upload contract, BLE UUIDs, audit trail.

## Reliability features (implemented)
- **Store-and-forward**: SOS is saved on the phone (localStorage outbox) until a neighbour acknowledges it; restored after reload.
- **Priority queues**: highest AI priority leaves each phone first; critical packets take two routes.
- **Dedupe**: SHA-256 `messageId` (`citizenId|createdAtMs`), checked by every node and again by the server (forged IDs rejected).
- **Rerouting**: failed or vanished links make the sender keep the packet and choose another neighbour.
- **Mesh → cloud sync**: if a gateway has the packet but the API is down, it is queued and retried automatically.
- **Server-side re-triage**: the API recomputes category/summary so clients are never trusted blindly.

## Run it
Requirements: Node 20.19+ / 22.12+, .NET 8 SDK.

```powershell
# terminal 1
cd rescuenet-dotnet ; dotnet restore ; dotnet run        # http://localhost:5080  (Swagger at /swagger)
# terminal 2
cd rescuenet-angular20 ; npm install ; npm start         # http://localhost:4200
```
Or `./start-backend.ps1` and `./start-frontend.ps1`. Delete `rescuenet.db` to reset data.

## 3-minute demo script
1. Sign in as the demo user. Open **Mesh network** → watch the 3D mesh.
2. Toggle **This phone has internet** off. Click **Send test SOS** → pulses hop phone → phone → gateway.
3. Click **Move a phone out of range** mid-flight → a reroute appears in the log.
4. Open **Incidents** → the SOS arrives with its relay path and AI priority. **Dispatch**, then **Mark rescued**.
5. **Incidents → Test gateway sync** shows duplicate packets being dropped. **Survival map** shows the flood cluster and dead zones.

## Honest limits
- The multi-hop routing you see in the browser is a **simulation of the mesh protocol**. Real peers can be attached with Web Bluetooth, but browsers cannot advertise, relay in the background or accept connections, and iOS Safari lacks Web Bluetooth. True phone-to-phone relay needs the native Android app implementing `docs/BLE-PROTOCOL.md` (the included Android project is only a starter).
- "AI triage" is transparent keyword + context scoring (works offline, explainable), not an LLM.
- Flood/dead-zone data is seeded demo data plus clustering of reports; map tiles need internet.
- Prototype security: change `Jwt:Key` and `Gateway:ApiKey` in `appsettings.json`, add per-gateway credentials, rate limits and privacy/retention rules before any real use. Not a certified emergency service — keep 112 available.

## Verification status
The Angular app was built with `ng build` (strict templates, no errors; production build only needs internet for Google Fonts inlining). The triage, SHA-256 and mesh-routing logic were exercised headlessly. The .NET API was **not compiled** in the generation environment (no .NET SDK / NuGet access) — run `dotnet build` once and tell me about any error.
