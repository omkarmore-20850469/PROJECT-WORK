$ErrorActionPreference = 'Stop'
Set-Location "$PSScriptRoot\rescuenet-dotnet"
dotnet restore
if ($LASTEXITCODE -ne 0) { throw 'dotnet restore failed.' }
dotnet run
