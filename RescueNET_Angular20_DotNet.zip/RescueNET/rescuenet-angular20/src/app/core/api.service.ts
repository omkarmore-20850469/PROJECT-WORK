import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { API_URL } from './config';
import { AuthResponse, UserInfo } from './models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  readonly user = signal<UserInfo | null>(this.readUser());
  readonly toast = signal('');
  constructor(private http: HttpClient) {}

  private readUser(): UserInfo | null {
    try { const s = localStorage.getItem('rescuenet_user'); return s ? JSON.parse(s) : null; } catch { return null; }
  }

  /** Low-level request. `quiet` skips the error toast (used for background polling and retry loops). */
  async request<T>(url: string, method: 'GET' | 'POST' | 'DELETE' = 'GET', body?: unknown, quiet = false): Promise<T> {
    try {
      return await firstValueFrom(method === 'GET' ? this.http.get<T>(API_URL + url)
        : method === 'DELETE' ? this.http.delete<T>(API_URL + url) : this.http.post<T>(API_URL + url, body ?? {}));
    } catch (e: any) {
      if (e?.status === 401 && this.user()) { this.logout(); location.assign('/login'); }
      const message = e?.error?.message || e?.error?.title || (typeof e?.error === 'string' && e.error.length < 200 ? e.error : '')
        || (e?.status === 0 ? 'Cannot reach the RescueNET API (port 5080). Your data stays queued on this device.' : `Request failed (${e?.status ?? 'unknown'}).`);
      if (!quiet) this.notify(message);
      const err: any = new Error(message); err.status = e?.status ?? 0; throw err;
    }
  }

  async login(email: string, password: string) { this.saveAuth(await this.request<AuthResponse>('/auth/login', 'POST', { email, password })); }
  async register(displayName: string, email: string, password: string, role: string) {
    this.saveAuth(await this.request<AuthResponse>('/auth/register', 'POST', { displayName, email, password, role }));
  }
  private saveAuth(r: AuthResponse) {
    localStorage.setItem('rescuenet_token', r.token);
    const u: UserInfo = { email: r.email, displayName: r.displayName, role: r.role };
    localStorage.setItem('rescuenet_user', JSON.stringify(u));
    this.user.set(u);
  }
  logout() { localStorage.removeItem('rescuenet_token'); localStorage.removeItem('rescuenet_user'); this.user.set(null); }
  token() { return localStorage.getItem('rescuenet_token') ?? ''; }

  notify(message: string) { this.toast.set(message); setTimeout(() => { if (this.toast() === message) this.toast.set(''); }, 4500); }
}
