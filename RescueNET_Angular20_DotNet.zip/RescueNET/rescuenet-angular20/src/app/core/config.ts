/** Where the RescueNET .NET API runs. Change this when deploying. */
export const API_ORIGIN = 'http://localhost:5080';
export const API_URL = `${API_ORIGIN}/api`;
export const HUB_URL = `${API_ORIGIN}/rescueHub`;

/**
 * RescueNET BLE GATT contract (see docs/BLE-PROTOCOL.md). A compatible phone app exposes this service;
 * the browser connects to it with Web Bluetooth and exchanges newline-delimited JSON packets.
 */
export const RESCUENET_SERVICE_UUID = '6e5a0001-b5a3-f393-e0a9-e50e24dcca9e';
export const RESCUENET_PACKET_CHAR_UUID = '6e5a0002-b5a3-f393-e0a9-e50e24dcca9e';
