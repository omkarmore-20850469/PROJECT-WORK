import { Injectable, NgZone, signal } from '@angular/core';
import { MeshPacket } from './models';
import { RESCUENET_PACKET_CHAR_UUID, RESCUENET_SERVICE_UUID } from './config';

export type NodeType = 'self' | 'relay' | 'gateway' | 'ble';

export interface MeshPkt {
  id: string; priority: number; category: string; payload: MeshPacket;
  path: string[]; ttl: number; inFlight: boolean; pending: number; acked: boolean;
}
export interface MeshNode {
  id: string; label: string; type: NodeType;
  x: number; y: number; z: number; vx: number; vy: number; vz: number;
  battery: number; online: boolean;
  queue: MeshPkt[]; seen: Set<string>; relayed: number; delivered: number;
  device?: any; char?: any; rxBuffer?: string;
}
export interface Pulse { id: number; from: string; to: string; t: number; pkt: MeshPkt; fail: boolean; hot: boolean; }
export interface MeshEvent { id: number; time: number; kind: 'forward' | 'deliver' | 'duplicate' | 'reroute' | 'store' | 'info' | 'ble'; text: string; }
export interface NodeView { id: string; label: string; type: NodeType; battery: number; links: number; queue: number; relayed: number; online: boolean; }
export interface MeshStats { nodes: number; online: number; links: number; gateways: number; inFlight: number; delivered: number; forwarded: number; duplicates: number; reroutes: number; queued: number; ble: number; }
export interface Journey { path: string[]; delivered: boolean; gateway?: string; }

const RANGE = 88;                 // radio range in scene units
const BOX = { x: 105, y: 55, z: 55 };
const FAIL_RATE = 0.08;           // simulated radio loss per hop
const HOP_SECONDS = 0.9;
const OUTBOX_KEY = 'rescuenet_outbox';

function rng(seed: number) { return () => { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/**
 * Browser-side model of a phone in the RescueNET mesh.
 *
 * Simulated peers (relays + gateways) demonstrate routing: store-and-forward queues, priority ordering,
 * duplicate suppression (SHA-256 message IDs), redundant paths for critical packets, rerouting around dead links,
 * and gateway upload. Real Bluetooth peers can be attached with Web Bluetooth (see connectBle()).
 */
@Injectable({ providedIn: 'root' })
export class MeshService {
  nodes: MeshNode[] = [];
  pulses: Pulse[] = [];
  links: [MeshNode, MeshNode][] = [];

  readonly view = signal<NodeView[]>([]);
  readonly stats = signal<MeshStats>({ nodes: 0, online: 0, links: 0, gateways: 0, inFlight: 0, delivered: 0, forwarded: 0, duplicates: 0, reroutes: 0, queued: 0, ble: 0 });
  readonly events = signal<MeshEvent[]>([]);
  readonly journey = signal<Record<string, Journey>>({});
  /** Simulated Wi-Fi / mobile data on THIS phone. Turn off to demonstrate an outage. */
  readonly selfInternet = signal(true);
  readonly bleSupported = typeof navigator !== 'undefined' && 'bluetooth' in navigator;

  readonly citizenId = this.loadCitizenId();
  /** The API upload hook, set by RescueStore. */
  onDeliver: (packet: MeshPacket, hopPath: string[], gateway: string) => void = () => {};
  /** Called when a packet arrives over a real Bluetooth link. */
  onIncoming: (packet: MeshPacket, via: string) => void = () => {};

  private adj = new Map<string, MeshNode[]>();
  private pulseId = 1; private eventId = 1; private tick = 0;
  private deliveredIds = new Set<string>();
  private counters = { forwarded: 0, duplicates: 0, reroutes: 0 };

  constructor(private zone: NgZone) {
    this.build();
    this.restoreOutbox();
    this.step();
    this.zone.runOutsideAngular(() => {
      let last = performance.now();
      setInterval(() => {
        const now = performance.now(); const dt = Math.min(0.3, (now - last) / 1000); last = now;
        const arrived = this.advance(dt);
        if (arrived.length) this.zone.run(() => { arrived.forEach(p => this.arrive(p)); this.publish(); });
      }, 80);
      setInterval(() => this.zone.run(() => this.step()), 600);
    });
  }

  get self(): MeshNode { return this.nodes.find(n => n.type === 'self')!; }
  get bleNodes(): MeshNode[] { return this.nodes.filter(n => n.type === 'ble'); }

  // ---------------------------------------------------------------- scene construction
  private loadCitizenId(): string {
    try {
      let id = localStorage.getItem('rescuenet_citizen');
      if (!id) { id = `CIT-${Math.floor(1000 + Math.random() * 9000)}`; localStorage.setItem('rescuenet_citizen', id); }
      return id;
    } catch { return `CIT-${Math.floor(1000 + Math.random() * 9000)}`; }
  }

  private blank(id: string, label: string, type: NodeType, x: number, y: number, z: number, battery: number): MeshNode {
    const drift = type === 'relay' ? 0.35 : 0;
    return { id, label, type, x, y, z, vx: (Math.random() - .5) * drift, vy: (Math.random() - .5) * drift, vz: (Math.random() - .5) * drift,
      battery, online: true, queue: [], seen: new Set(), relayed: 0, delivered: 0 };
  }

  private build() {
    const letters = 'ABCDEFGHJKLM'.split('');
    for (let attempt = 0; attempt < 60; attempt++) {
      const r = rng(7 + attempt * 13);
      this.nodes = [
        this.blank('self', `YOU-${this.citizenId.slice(-4)}`, 'self', -BOX.x, 0, 0, 76),
        this.blank('gw1', 'GW-MUM-01', 'gateway', BOX.x, -28, 12, 100),
        this.blank('gw2', 'GW-MUM-02', 'gateway', BOX.x - 10, 34, -22, 100)
      ];
      for (let i = 0; i < 12; i++) {
        this.nodes.push(this.blank(`r${i}`, `${letters[i]}-${10 + Math.floor(r() * 80)}`, 'relay',
          (r() * 2 - 1) * (BOX.x - 15), (r() * 2 - 1) * BOX.y, (r() * 2 - 1) * BOX.z, 20 + Math.floor(r() * 75)));
      }
      this.rebuildLinks();
      const dist = this.distances();
      const reachable = this.nodes.filter(n => dist.has(n.id)).length;
      if (dist.has('self') && reachable >= this.nodes.length - 2) break;
    }
  }

  // ---------------------------------------------------------------- graph helpers
  private dist3(a: MeshNode, b: MeshNode) { return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z); }

  private rebuildLinks() {
    this.adj = new Map(this.nodes.map(n => [n.id, [] as MeshNode[]]));
    this.links = [];
    const sim = this.nodes.filter(n => n.type !== 'ble' && n.online);
    for (let i = 0; i < sim.length; i++) for (let j = i + 1; j < sim.length; j++) {
      if (this.dist3(sim[i]!, sim[j]!) < RANGE) this.connect(sim[i]!, sim[j]!);
    }
    const self = this.self;
    if (self.online) this.nodes.filter(n => n.type === 'ble' && n.online).forEach(b => this.connect(self, b));
  }
  private connect(a: MeshNode, b: MeshNode) { this.adj.get(a.id)!.push(b); this.adj.get(b.id)!.push(a); this.links.push([a, b]); }
  private linked(a: MeshNode, b: MeshNode) { return !!this.adj.get(a.id)?.includes(b); }
  isGateway(n: MeshNode) { return n.online && (n.type === 'gateway' || (n.type === 'self' && this.selfInternet())); }

  /** Hop distance from every node to the nearest internet-connected node (multi-source BFS). */
  private distances(): Map<string, number> {
    const dist = new Map<string, number>(); const queue: MeshNode[] = [];
    this.nodes.filter(n => this.isGateway(n)).forEach(n => { dist.set(n.id, 0); queue.push(n); });
    while (queue.length) {
      const cur = queue.shift()!; const d = dist.get(cur.id)!;
      for (const nb of this.adj.get(cur.id) ?? []) {
        if (nb.type === 'ble' || dist.has(nb.id)) continue; // real BLE peers are leaves: we can't see beyond them
        dist.set(nb.id, d + 1); queue.push(nb);
      }
    }
    return dist;
  }

  // ---------------------------------------------------------------- simulation loop
  private step() {
    this.tick++;
    // gentle mobility: phones move, links appear and disappear
    for (const n of this.nodes) {
      if (n.type !== 'relay') continue;
      n.x += n.vx; n.y += n.vy; n.z += n.vz;
      if (Math.abs(n.x) > BOX.x - 8) n.vx *= -1; if (Math.abs(n.y) > BOX.y) n.vy *= -1; if (Math.abs(n.z) > BOX.z) n.vz *= -1;
    }
    this.rebuildLinks();
    const dist = this.distances();
    for (const n of this.nodes) this.route(n, dist);
    this.persistOutbox();
    this.publish();
  }

  private route(n: MeshNode, dist: Map<string, number>) {
    if (!n.online || !n.queue.length) return;
    // highest priority first: critical packets overtake chatter
    const batch = n.queue.filter(p => !p.inFlight).sort((a, b) => b.priority - a.priority).slice(0, 2);
    for (const p of batch) {
      if (this.isGateway(n)) { this.deliver(n, p); continue; }
      if (p.ttl <= 0) { n.queue = n.queue.filter(q => q !== p); this.log('info', `${n.label} dropped ${this.short(p.id)} (TTL expired)`); continue; }
      const targets = this.pickNext(n, p, dist);
      if (!targets.length) { if (this.tick % 8 === 0) this.log('store', `No route from ${n.label} · ${this.short(p.id)} stays stored and will be retried`); continue; }
      p.inFlight = true; p.pending = targets.length;
      for (const t of targets) {
        this.pulses.push({ id: this.pulseId++, from: n.id, to: t.id, t: 0, pkt: p, fail: Math.random() < FAIL_RATE, hot: p.priority >= 90 });
      }
    }
  }

  private pickNext(n: MeshNode, p: MeshPkt, dist: Map<string, number>): MeshNode[] {
    const mine = dist.get(n.id) ?? Infinity;
    let cands = (this.adj.get(n.id) ?? []).filter(m => m.online && m.type !== 'ble' && dist.has(m.id) && !p.path.includes(m.label));
    const closer = cands.filter(m => dist.get(m.id)! < mine);
    if (closer.length) cands = closer;
    cands.sort((a, b) => dist.get(a.id)! - dist.get(b.id)! || b.battery - a.battery);
    return cands.slice(0, p.priority >= 90 ? 2 : 1); // critical SOS take two routes at once
  }

  private advance(dt: number): Pulse[] {
    const done: Pulse[] = [];
    for (const p of this.pulses) {
      p.t += dt / HOP_SECONDS;
      if (p.t >= 1 || (p.fail && p.t >= .55)) done.push(p);
    }
    if (done.length) this.pulses = this.pulses.filter(p => !done.includes(p));
    return done;
  }

  private arrive(pulse: Pulse) {
    const from = this.nodes.find(n => n.id === pulse.from); const to = this.nodes.find(n => n.id === pulse.to);
    const pkt = pulse.pkt;
    if (!from) return;
    pkt.pending = Math.max(0, pkt.pending - 1);
    if (pulse.fail || !to || !to.online || !this.linked(from, to)) {
      this.counters.reroutes++;
      this.log('reroute', `Link ${from.label} → ${to?.label ?? '?'} lost · ${from.label} keeps ${this.short(pkt.id)} and chooses another route`);
      if (pkt.pending === 0 && !pkt.acked) pkt.inFlight = false;
      return;
    }
    if (!pkt.acked) { pkt.acked = true; from.queue = from.queue.filter(q => q !== pkt); } // acknowledgement: sender may drop its copy
    if (to.seen.has(pkt.id)) {
      this.counters.duplicates++;
      this.log('duplicate', `${to.label} already had ${this.short(pkt.id)} · duplicate dropped`);
      return;
    }
    to.seen.add(pkt.id); to.relayed++; this.counters.forwarded++;
    const copy: MeshPkt = { ...pkt, path: [...pkt.path, to.label], ttl: pkt.ttl - 1, inFlight: false, pending: 0, acked: false };
    to.queue.push(copy);
    this.updateJourney(copy);
    this.log('forward', `${from.label} → ${to.label} · ${pkt.category} priority ${pkt.priority}`);
  }

  private deliver(n: MeshNode, p: MeshPkt) {
    n.queue = n.queue.filter(q => q !== p);
    n.delivered++;
    const gateway = n.type === 'self' ? `${n.label}-UPLINK` : n.label;
    const hopPath = p.path.filter((x, i) => !(i === p.path.length - 1 && x === n.label && p.path.length > 1));
    const first = !this.deliveredIds.has(p.id);
    this.deliveredIds.add(p.id);
    this.updateJourney(p, gateway);
    this.log('deliver', `${gateway} uploading ${this.short(p.id)} to the command center · ${hopPath.length} hop${hopPath.length === 1 ? '' : 's'}${first ? '' : ' (second route)'}`);
    this.onDeliver(p.payload, hopPath, gateway);
  }

  // ---------------------------------------------------------------- public actions
  send(payload: MeshPacket) {
    const self = this.self;
    const pkt: MeshPkt = { id: payload.messageId, priority: payload.priority ?? 50, category: payload.category ?? 'General', payload,
      path: [self.label], ttl: 14, inFlight: false, pending: 0, acked: false };
    self.seen.add(pkt.id); self.queue.push(pkt);
    this.updateJourney(pkt);
    this.log('store', `${self.label} stored ${pkt.category} ${this.short(pkt.id)} (priority ${pkt.priority}) until it is forwarded`);
    void this.writeToBle(pkt);
    this.persistOutbox();
    this.step();
  }

  addNode() {
    const used = new Set(this.nodes.map(n => n.label));
    let label = ''; do { label = `${'NPQRSTUVWXYZ'[Math.floor(Math.random() * 12)]}-${10 + Math.floor(Math.random() * 80)}`; } while (used.has(label));
    const n = this.blank(`r${Date.now()}`, label, 'relay', (Math.random() * 2 - 1) * (BOX.x - 15), (Math.random() * 2 - 1) * BOX.y, (Math.random() * 2 - 1) * BOX.z, 30 + Math.floor(Math.random() * 65));
    this.nodes.push(n);
    this.log('info', `${label} joined the mesh · network grows as more phones turn MESH on`);
    this.step();
  }

  /** Simulates a phone walking out of range or powering off, preferring one that is currently carrying traffic. */
  dropNode() {
    const relays = this.nodes.filter(n => n.type === 'relay' && n.online);
    if (!relays.length) return;
    const busy = relays.filter(n => n.queue.length || this.pulses.some(p => p.to === n.id));
    const pool = busy.length ? busy : relays;
    const victim = pool[Math.floor(Math.random() * pool.length)]!;
    victim.online = false;
    this.log('reroute', `${victim.label} went out of range · mesh recalculates routes around it`);
    this.step();
  }

  restoreAll() {
    this.nodes.forEach(n => { if (n.type !== 'ble') n.online = true; });
    this.log('info', 'All simulated phones are back in range');
    this.step();
  }

  toggleSelfInternet() {
    this.selfInternet.update(v => !v);
    this.log('info', this.selfInternet() ? 'Internet restored on this phone · it can act as a gateway again' : 'Internet disabled on this phone · SOS must hop through the mesh');
    this.step();
  }

  // ---------------------------------------------------------------- real Bluetooth (Web Bluetooth)
  /**
   * Opens the browser's Bluetooth chooser and attaches the chosen device as a real mesh neighbour.
   * If the device exposes the RescueNET GATT service, packets are exchanged with it (write + notify).
   * Web Bluetooth is a *central-role* API: a web page can connect to devices but cannot advertise or relay
   * on its own. Full phone-to-phone relaying needs the native Android app (see docs/BLE-PROTOCOL.md).
   */
  async connectBle(): Promise<string> {
    const nav: any = navigator;
    if (!nav.bluetooth) throw new Error('Web Bluetooth is not available in this browser. Use Chrome or Edge on desktop/Android over HTTPS or localhost.');
    let device: any;
    try {
      device = await nav.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: [RESCUENET_SERVICE_UUID, 'battery_service'] });
    } catch (e: any) {
      if (e?.name === 'NotFoundError') throw new Error('No Bluetooth device was selected.');
      throw new Error(e?.message || 'Bluetooth request failed.');
    }
    const label = (device.name || `BLE-${String(device.id).slice(0, 4)}`).slice(0, 18);
    const existing = this.nodes.find(n => n.device?.id === device.id);
    const node = existing ?? this.blank(`ble-${device.id}`, label, 'ble', -BOX.x + 60 + Math.random() * 20, 40 + Math.random() * 15, (Math.random() - .5) * 60, 0);
    node.device = device; node.online = false; node.rxBuffer = '';
    if (!existing) this.nodes.push(node);
    device.addEventListener('gattserverdisconnected', () => this.zone.run(() => {
      node.online = false; node.char = undefined;
      this.log('ble', `${node.label} disconnected`); this.step();
    }));
    let note = 'connected as a plain Bluetooth neighbour';
    try {
      const server = await device.gatt.connect();
      node.online = true;
      try {
        const svc = await server.getPrimaryService(RESCUENET_SERVICE_UUID);
        const ch = await svc.getCharacteristic(RESCUENET_PACKET_CHAR_UUID);
        await ch.startNotifications();
        ch.addEventListener('characteristicvaluechanged', (ev: any) => this.zone.run(() => this.onBleValue(node, ev)));
        node.char = ch; note = 'RescueNET mesh service found · packets will be exchanged over Bluetooth';
      } catch { /* device is not a RescueNET phone */ }
      try {
        const bsvc = await server.getPrimaryService('battery_service');
        const bch = await bsvc.getCharacteristic('battery_level');
        node.battery = (await bch.readValue()).getUint8(0);
      } catch { /* battery service optional */ }
    } catch (e: any) {
      node.online = false;
      this.log('ble', `Could not open a GATT connection to ${node.label}: ${e?.message ?? 'unknown error'}`);
      this.step();
      throw new Error(`Could not connect to ${node.label}. Make sure it is powered on, in range and not paired elsewhere.`);
    }
    this.log('ble', `${node.label} ${note}`);
    this.step();
    return `${node.label} ${note}`;
  }

  disconnectBle(node: MeshNode) {
    try { node.device?.gatt?.disconnect(); } catch { /* ignore */ }
    this.nodes = this.nodes.filter(n => n !== node);
    this.step();
  }

  private async writeToBle(pkt: MeshPkt) {
    const wire = JSON.stringify({ ...pkt.payload, hopPath: pkt.path }) + '\n';
    const data = new TextEncoder().encode(wire);
    for (const n of this.bleNodes.filter(b => b.online && b.char)) {
      try {
        for (let i = 0; i < data.length; i += 180) {
          const chunk = data.slice(i, i + 180);
          if (n.char.writeValueWithoutResponse) await n.char.writeValueWithoutResponse(chunk); else await n.char.writeValue(chunk);
        }
        this.zone.run(() => this.log('ble', `${this.short(pkt.id)} written to ${n.label} over Bluetooth (${data.length} bytes)`));
      } catch (e: any) {
        this.zone.run(() => this.log('ble', `Bluetooth write to ${n.label} failed: ${e?.message ?? 'error'} · packet remains stored`));
      }
    }
  }

  private onBleValue(node: MeshNode, ev: any) {
    node.rxBuffer = (node.rxBuffer ?? '') + new TextDecoder().decode(ev.target.value);
    let idx: number;
    while ((idx = node.rxBuffer.indexOf('\n')) >= 0) {
      const line = node.rxBuffer.slice(0, idx); node.rxBuffer = node.rxBuffer.slice(idx + 1);
      try {
        const packet = JSON.parse(line) as MeshPacket;
        if (!packet.messageId || this.self.seen.has(packet.messageId)) { this.counters.duplicates++; this.log('duplicate', `Duplicate ${this.short(packet.messageId ?? '?')} from ${node.label} dropped`); continue; }
        const self = this.self; self.seen.add(packet.messageId);
        const pkt: MeshPkt = { id: packet.messageId, priority: packet.priority ?? 50, category: packet.category ?? 'General', payload: packet,
          path: [...(packet.hopPath ?? []), node.label, self.label].filter((v, i, a) => a.indexOf(v) === i), ttl: 12, inFlight: false, pending: 0, acked: false };
        self.queue.push(pkt); self.relayed++;
        this.log('ble', `Received ${pkt.category} ${this.short(pkt.id)} from ${node.label} over Bluetooth`);
        this.onIncoming(packet, node.label);
      } catch { this.log('ble', `Ignored a malformed packet from ${node.label}`); }
    }
    this.step();
  }

  // ---------------------------------------------------------------- bookkeeping
  private short(id: string) { return `#${id.slice(0, 6)}`; }

  private updateJourney(p: MeshPkt, gateway?: string) {
    if (p.path[0] !== this.self.label) return;
    this.journey.update(j => {
      const cur = j[p.id];
      const path = cur && cur.path.length > p.path.length ? cur.path : p.path;
      return { ...j, [p.id]: { path, delivered: !!gateway || !!cur?.delivered, gateway: gateway ?? cur?.gateway } };
    });
  }

  private log(kind: MeshEvent['kind'], text: string) {
    this.events.update(list => [{ id: this.eventId++, time: Date.now(), kind, text }, ...list].slice(0, 80));
  }

  private publish() {
    const links = new Map<string, number>();
    this.links.forEach(([a, b]) => { links.set(a.id, (links.get(a.id) ?? 0) + 1); links.set(b.id, (links.get(b.id) ?? 0) + 1); });
    this.view.set(this.nodes.map(n => ({ id: n.id, label: n.label, type: n.type, battery: Math.round(n.battery), links: links.get(n.id) ?? 0, queue: n.queue.length, relayed: n.relayed, online: n.online })));
    this.stats.set({
      nodes: this.nodes.length, online: this.nodes.filter(n => n.online).length, links: this.links.length,
      gateways: this.nodes.filter(n => this.isGateway(n)).length, inFlight: this.pulses.length, delivered: this.deliveredIds.size,
      forwarded: this.counters.forwarded, duplicates: this.counters.duplicates, reroutes: this.counters.reroutes,
      queued: this.nodes.reduce((a, n) => a + n.queue.length, 0), ble: this.bleNodes.filter(b => b.online).length
    });
  }

  // ---------------------------------------------------------------- local persistence (store-and-forward survives a reload)
  private persistOutbox() {
    try {
      const mine = this.self.queue.filter(p => p.path[0] === this.self.label).map(p => ({ payload: p.payload, priority: p.priority, category: p.category, path: p.path }));
      localStorage.setItem(OUTBOX_KEY, JSON.stringify(mine));
    } catch { /* storage unavailable */ }
  }
  private restoreOutbox() {
    try {
      const raw = localStorage.getItem(OUTBOX_KEY); if (!raw) return;
      const items = JSON.parse(raw) as { payload: MeshPacket; priority: number; category: string; path: string[] }[];
      for (const i of items) {
        if (this.self.seen.has(i.payload.messageId)) continue;
        this.self.seen.add(i.payload.messageId);
        this.self.queue.push({ id: i.payload.messageId, priority: i.priority, category: i.category, payload: i.payload, path: [this.self.label], ttl: 14, inFlight: false, pending: 0, acked: false });
      }
      if (items.length) this.log('store', `${items.length} unsent SOS packet${items.length === 1 ? '' : 's'} restored from this phone's storage`);
    } catch { /* ignore corrupt outbox */ }
  }
  clearOutbox() { this.self.queue = []; this.persistOutbox(); this.step(); }
}

