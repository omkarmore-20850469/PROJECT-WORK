/**
 * On-device emergency triage. This is the TypeScript mirror of the server's Triage.cs, so a phone with
 * no internet scores an SOS exactly the way the cloud will. Rules are transparent keyword + context
 * weights (AI-assisted prioritisation, not a black-box LLM dependency).
 */
export interface TriageResult {
  category: string; severity: 'Critical' | 'High' | 'Moderate' | 'Low'; priority: number; riskScore: number;
  people: number; mobilityIssue: boolean; hazards: string[]; summary: string; matched: string[];
}

const RULES: { category: string; base: number; keywords: string[] }[] = [
  { category: 'Collapse', base: 100, keywords: ['collapse', 'collapsed', 'rubble', 'debris', 'building fell', 'caved'] },
  { category: 'Medical', base: 95, keywords: ['bleeding', 'injured', 'injury', 'unconscious', 'heart', 'breathing', 'pregnant', 'fracture', 'broken', 'medical', 'insulin', 'ambulance', 'faint'] },
  { category: 'Fire', base: 92, keywords: ['fire', 'smoke', 'burning', 'blaze', 'explosion'] },
  { category: 'Trapped', base: 90, keywords: ['trapped', 'stuck', 'cannot get out', "can't get out", 'locked in', 'pinned'] },
  { category: 'Flood', base: 85, keywords: ['flood', 'water entering', 'water rising', 'rising water', 'submerged', 'drown', 'knee level', 'waist level', 'water is entering', 'water level'] },
  { category: 'Warning', base: 60, keywords: ['warning', 'danger', 'hazard', 'live wire', 'gas leak', 'landslide', 'unsafe'] },
  { category: 'Supplies', base: 50, keywords: ['food', 'hungry', 'drinking water', 'supplies', 'medicines', 'medicine', 'thirst', 'blanket', 'need water'] },
  { category: 'Safe', base: 20, keywords: ['i am safe', "i'm safe", 'i’m safe', 'we are safe', 'safe now', 'all ok', 'no injuries'] },
  { category: 'Noise', base: 5, keywords: ['wifi', 'wi-fi', 'internet', 'recharge', 'data pack'] }
];
const MOBILITY = ["can't walk", 'cannot walk', 'cant walk', 'wheelchair', 'elderly', 'grandmother', 'grandfather', 'old man', 'old woman', 'child', 'children', 'baby', 'infant', 'disabled', 'pregnant', 'bedridden'];
const HAZARDS: { hazard: string; keywords: string[] }[] = [
  { hazard: 'Flood risk', keywords: ['water', 'flood', 'rising', 'submerged'] },
  { hazard: 'Structural risk', keywords: ['collapse', 'crack', 'rubble', 'building'] },
  { hazard: 'Fire / smoke', keywords: ['fire', 'smoke', 'burning'] },
  { hazard: 'Medical need', keywords: ['bleeding', 'injured', 'unconscious', 'medicine', 'insulin', 'heart', 'breathing'] },
  { hazard: 'Mobility limited', keywords: ["can't walk", 'cannot walk', 'wheelchair', 'elderly', 'grandmother', 'grandfather', 'bedridden'] }
];

export function analyzeTriage(text: string | null | undefined, category: string | null | undefined, people: number | null | undefined): TriageResult {
  const t = (text ?? '').toLowerCase();
  let best: string | null = null; let bestBase = -1; const matched: string[] = [];
  for (const r of RULES) {
    const hits = r.keywords.filter(k => t.includes(k));
    if (hits.length) { matched.push(...hits); if (r.base > bestBase) { bestBase = r.base; best = r.category; } }
  }
  const picked = RULES.find(r => r.category.toLowerCase() === (category ?? '').toLowerCase());
  if (picked && picked.base > bestBase) { bestBase = picked.base; best = picked.category; }
  if (!best) { best = 'General'; bestBase = 40; }

  const count = Math.min(1000, Math.max(1, Math.floor(people ?? 1)));
  const mobilityIssue = MOBILITY.some(w => t.includes(w));
  const hazards = HAZARDS.filter(h => h.keywords.some(k => t.includes(k))).map(h => h.hazard);
  if (best === 'Flood' && !hazards.includes('Flood risk')) hazards.push('Flood risk');

  let score = bestBase + Math.min(8, (count - 1) * 2) + (mobilityIssue ? 5 : 0);
  if (best === 'Safe' || best === 'Noise') score = Math.min(score, 25);
  score = Math.max(0, Math.min(100, score));
  const riskScore = score >= 90 ? 4 : score >= 70 ? 3 : score >= 40 ? 2 : 1;
  const severity = (['Low', 'Low', 'Moderate', 'High', 'Critical'] as const)[riskScore];
  const summary = `${severity} · ${best} · ${count} ${count === 1 ? 'person' : 'people'}`
    + (mobilityIssue ? ' · mobility limited' : '') + (hazards.length ? ` · ${hazards.join(', ').toLowerCase()}` : '');
  return { category: best, severity, priority: score, riskScore, people: count, mobilityIssue, hazards, summary, matched: [...new Set(matched)] };
}
