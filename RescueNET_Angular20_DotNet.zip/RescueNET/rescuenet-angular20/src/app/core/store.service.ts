import { Injectable, computed, effect, signal } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { ApiService } from './api.service';
import { HUB_URL } from './config';
import { ActivityItem, GatewayInfo, Incident, MapZone, MeshPacket, Team, RISK_LABEL } from './models';
import { MeshService } from './mesh.service';
import { analyzeTriage } from './triage';
import { sha256Hex } from './sha256';

export interface SosDraft { category: string; note: string; people: number; latitude: number; longitude: number; batteryPct: number | null; }
interface PendingUpload { gateway: string; packet: MeshPacket; }
export const DEFAULT_LOCATION = { latitude: 19.0760, longitude: 72.8777 }; // Mumbai

export interface FloodCluster { latitude: number; longitude: number; reports: number; confidence: number; lastMs: number; }

const PENDING_KEY = 'rescuenet_pending_uploads';

/**
 * Central, offline-first state for the whole app. Server data arrives over REST + SignalR; anything created on
 * this phone is first written to the mesh outbox and to local storage, then forwarded when a route exists.
 */
@Injectable({ providedIn: 'root' })
export class RescueStore {
  readonly incidents = signal<Incident[]>([]);
  readonly teams = signal<Team[]>([]);
  readonly zones = signal<MapZone[]>([]);
  readonly activity = signal<ActivityItem[]>([]);
  readonly gateways = signal<GatewayInfo[]>([]);
  readonly apiOnline = signal(false);
  readonly liveLink = signal(false);
  readonly loading = signal(true);
  readonly location = signal({ ...DEFAULT_LOCATION });
  readonly locationKnown = signal(false);
  readonly uploaded = signal<Set<string>>(new Set());
  readonly pendingCount = signal(this.loadPending().length);

  private hub?: signalR.HubConnection;
  private retryTimer?: any; private pingTimer?: any; private started = false;

  readonly queue = computed(() => this.incidents().filter(i => i.status !== 'Rescued')
    .sort((a, b) => b.priority - a.priority || a.createdAtMs - b.createdAtMs));

  readonly stats = computed(() => {
    const all = this.incidents(); const open = all.filter(i => i.status !== 'Rescued');
    return {
      open: open.length, critical: open.filter(i => i.riskScore === 4).length,
      high: open.filter(i => i.riskScore === 3).length, pending: open.filter(i => i.status === 'Pending').length,
      dispatched: open.filter(i => i.status === 'Dispatched').length, rescued: all.filter(i => i.status === 'Rescued').length,
      people: open.reduce((n, i) => n + i.people, 0), teamsFree: this.teams().filter(t => t.status === 'Available').length,
      avgHops: open.length ? open.reduce((n, i) => n + i.hopCount, 0) / open.length : 0
    };
  });

  /** Independent flood reports within ~600 m are merged into a flood zone with a growing confidence value. */
  readonly floodZones = computed<FloodCluster[]>(() => {
    const reports = this.incidents().filter(i => i.category === 'Flood' && i.status !== 'Rescued');
    const clusters: { lat: number; lon: number; n: number; last: number }[] = [];
    for (const r of reports) {
      const c = clusters.find(k => this.km(k.lat, k.lon, r.latitude, r.longitude) < 0.6);
      if (c) { c.lat = (c.lat * c.n + r.latitude) / (c.n + 1); c.lon = (c.lon * c.n + r.longitude) / (c.n + 1); c.n++; c.last = Math.max(c.last, r.createdAtMs); }
      else clusters.push({ lat: r.latitude, lon: r.longitude, n: 1, last: r.createdAtMs });
    }
    return clusters.filter(c => c.n >= 3).map(c => ({ latitude: c.lat, longitude: c.lon, reports: c.n, confidence: Math.min(98, 45 + c.n * 9), lastMs: c.last }));
  });

  readonly deadZones = computed(() => this.zones().filter(z => z.type === 'DeadZone'));

  /** Hospitals, water points, shelters and rescue bases sorted by distance from this phone. */
  readonly nearby = computed(() => {
    const loc = this.location();
    return this.zones().filter(z => z.type !== 'DeadZone')
      .map(z => ({ zone: z, km: this.km(loc.latitude, loc.longitude, z.latitude, z.longitude) }))
      .sort((a, b) => a.km - b.km);
  });

  constructor(private api: ApiService, private mesh: MeshService) {
    this.mesh.onDeliver = (packet, hopPath, gateway) => void this.upload({ ...packet, hopPath }, gateway);
    this.mesh.onIncoming = (packet, via) => {
      this.addLocalIncident(packet, `${via} → ${this.mesh.self.label} (Bluetooth)`, 'BLE-LOCAL');
      this.api.notify(`SOS received over Bluetooth from ${via}`);
    };
    effect(() => { if (this.api.user()) this.start(); else this.stop(); });
  }

  // ------------------------------------------------------------------ lifecycle
  private start() {
    if (this.started) return;
    this.started = true;
    void this.refreshAll();
    void this.connectHub();
    this.pingTimer = setInterval(() => void this.ping(), 10_000);
    this.retryTimer = setInterval(() => void this.flushPending(), 8_000);
    this.locate(true);
  }
  private stop() {
    this.started = false;
    clearInterval(this.pingTimer); clearInterval(this.retryTimer);
    void this.hub?.stop(); this.hub = undefined;
    this.incidents.set([]); this.teams.set([]); this.zones.set([]); this.activity.set([]); this.liveLink.set(false); this.apiOnline.set(false);
  }

  async refreshAll() {
    this.loading.set(true);
    try {
      const [incidents, teams, zones, activity, gateways] = await Promise.all([
        this.api.request<Incident[]>('/signals', 'GET', undefined, true),
        this.api.request<Team[]>('/teams', 'GET', undefined, true),
        this.api.request<MapZone[]>('/zones', 'GET', undefined, true),
        this.api.request<ActivityItem[]>('/activity', 'GET', undefined, true),
        this.api.request<GatewayInfo[]>('/mesh/gateways', 'GET', undefined, true)
      ]);
      this.mergeIncidents(incidents); this.teams.set(teams); this.zones.set(zones); this.activity.set(activity); this.gateways.set(gateways);
      this.apiOnline.set(true);
    } catch { this.apiOnline.set(false); }
    finally { this.loading.set(false); }
  }

  private async ping() {
    try { await this.api.request('/health', 'GET', undefined, true); if (!this.apiOnline()) { this.apiOnline.set(true); void this.refreshAll(); } }
    catch { this.apiOnline.set(false); }
  }

  private async connectHub() {
    const hub = new signalR.HubConnectionBuilder()
      .withUrl(HUB_URL, { accessTokenFactory: () => this.api.token() })
      .withAutomaticReconnect([0, 2_000, 5_000, 10_000, 30_000]).build();
    this.hub = hub;
    hub.on('ReceiveNewSignals', (incoming: Incident[]) => {
      this.mergeIncidents(incoming);
      const crit = incoming.filter(i => i.riskScore === 4).length;
      this.api.notify(`${incoming.length} new SOS via mesh${crit ? ` · ${crit} critical` : ''}`);
    });
    hub.on('SignalUpdated', (i: Incident) => this.mergeIncidents([i]));
    hub.on('TeamUpdated', (t: Team) => this.teams.update(cur => cur.some(x => x.id === t.id) ? cur.map(x => x.id === t.id ? t : x) : [...cur, t]));
    hub.on('ActivityAdded', (a: ActivityItem) => this.activity.update(cur => [a, ...cur.filter(x => x.id !== a.id)].slice(0, 100)));
    hub.onreconnecting(() => this.liveLink.set(false));
    hub.onreconnected(() => { this.liveLink.set(true); this.apiOnline.set(true); void this.refreshAll(); void this.flushPending(); });
    hub.onclose(() => this.liveLink.set(false));
    await this.startHub();
  }
  private async startHub() {
    const hub = this.hub; if (!hub || !this.started || hub.state !== signalR.HubConnectionState.Disconnected) return;
    try { await hub.start(); this.liveLink.set(true); this.apiOnline.set(true); }
    catch { this.liveLink.set(false); setTimeout(() => void this.startHub(), 8_000); }
  }

  // ------------------------------------------------------------------ location / device info
  locate(silent = false): Promise<void> {
    return new Promise(resolve => {
      if (!('geolocation' in navigator)) { if (!silent) this.api.notify('Location is not available on this device. Using the default area.'); return resolve(); }
      navigator.geolocation.getCurrentPosition(
        pos => { this.location.set({ latitude: +pos.coords.latitude.toFixed(5), longitude: +pos.coords.longitude.toFixed(5) }); this.locationKnown.set(true); resolve(); },
        () => { if (!silent) this.api.notify('Location permission was not granted. Using the default area; you can edit coordinates manually.'); resolve(); },
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 60_000 });
    });
  }
  async batteryPct(): Promise<number | null> {
    try { const b = await (navigator as any).getBattery?.(); return b ? Math.round(b.level * 100) : null; } catch { return null; }
  }

  // ------------------------------------------------------------------ SOS creation (offline-first)
  async submitSos(draft: SosDraft): Promise<string> {
    const t = analyzeTriage(draft.note, draft.category, draft.people);
    const createdAtMs = Date.now();
    const citizenId = this.mesh.citizenId;
    const payload: MeshPacket = {
      messageId: await sha256Hex(`${citizenId}|${createdAtMs}`), citizenId, latitude: draft.latitude, longitude: draft.longitude,
      riskScore: t.riskScore, people: t.people, note: draft.note.trim().slice(0, 280) || null, createdAtMs, hopPath: [],
      category: t.category, priority: t.priority, batteryPct: draft.batteryPct
    };
    this.addLocalIncident(payload, `${this.mesh.self.label} (queued on this phone)`, 'LOCAL');
    this.mesh.send(payload);
    return payload.messageId;
  }

  private addLocalIncident(p: MeshPacket, path: string, gateway: string) {
    const t = analyzeTriage(p.note, p.category, p.people);
    const local: Incident = {
      messageId: p.messageId, citizenId: p.citizenId, latitude: p.latitude, longitude: p.longitude, riskScore: p.riskScore,
      priority: p.priority ?? t.priority, category: p.category ?? t.category, people: p.people, note: p.note, triageSummary: t.summary,
      mobilityIssue: t.mobilityIssue, batteryPct: p.batteryPct, status: 'Pending', createdAtMs: p.createdAtMs, receivedAtMs: p.createdAtMs,
      hopPath: path, hopCount: 0, gatewayId: gateway
    };
    this.mergeIncidents([local]);
  }

  /** Upload from a gateway node. If the API is unreachable the packet is kept and retried (mesh → cloud sync). */
  private async upload(packet: MeshPacket, gateway: string) {
    try {
      await this.api.request('/mesh/relay-upload', 'POST', { gatewayLabel: gateway, packets: [packet] }, true);
      this.uploaded.update(s => new Set(s).add(packet.messageId));
      this.apiOnline.set(true);
    } catch {
      this.apiOnline.set(false);
      const list = this.loadPending(); list.push({ gateway, packet }); this.savePending(list);
      this.api.notify('Packet reached a gateway but the cloud is unreachable. It is stored and will sync automatically.');
    }
  }
  async flushPending() {
    const list = this.loadPending(); if (!list.length) return;
    const byGw = new Map<string, MeshPacket[]>();
    list.forEach(i => byGw.set(i.gateway, [...(byGw.get(i.gateway) ?? []), i.packet]));
    try {
      for (const [gateway, packets] of byGw) await this.api.request('/mesh/relay-upload', 'POST', { gatewayLabel: gateway, packets }, true);
      this.uploaded.update(s => { const n = new Set(s); list.forEach(i => n.add(i.packet.messageId)); return n; });
      this.savePending([]); this.apiOnline.set(true);
      this.api.notify(`${list.length} stored packet${list.length === 1 ? '' : 's'} synchronised with the command center.`);
      void this.refreshAll();
    } catch { /* still offline; keep for the next attempt */ }
  }
  private loadPending(): PendingUpload[] { try { return JSON.parse(localStorage.getItem(PENDING_KEY) ?? '[]'); } catch { return []; } }
  private savePending(list: PendingUpload[]) { try { localStorage.setItem(PENDING_KEY, JSON.stringify(list)); } catch { /* ignore */ } this.pendingCount.set(list.length); }

  // ------------------------------------------------------------------ operator actions
  async dispatch(id: string, teamId?: number) {
    try {
      const updated = await this.api.request<Incident>(`/signals/${encodeURIComponent(id)}/dispatch`, 'POST', { teamId: teamId ?? null });
      this.mergeIncidents([updated]); this.api.notify(`${updated.assignedTeamName} dispatched to ${updated.citizenId}`);
    } catch { /* toast already shown */ }
  }
  async markRescued(id: string) {
    try { const updated = await this.api.request<Incident>(`/signals/${encodeURIComponent(id)}/rescued`, 'POST'); this.mergeIncidents([updated]); this.api.notify(`${updated.citizenId} marked as rescued`); }
    catch { /* toast already shown */ }
  }
  async simulateGateway(count = 12) {
    try {
      const r = await this.api.request<{ newAlerts: number; duplicates: number; rejected: number }>(`/dev/simulate?count=${count}`, 'POST');
      this.api.notify(`Gateway sync: ${r.newAlerts} new · ${r.duplicates} duplicates dropped · ${r.rejected} rejected`);
      void this.refreshAll();
    } catch { /* toast already shown */ }
  }

  // ------------------------------------------------------------------ helpers
  private mergeIncidents(incoming: Incident[]) {
    this.incidents.update(cur => {
      const map = new Map(cur.map(i => [i.messageId, i]));
      incoming.forEach(i => map.set(i.messageId, i));
      return [...map.values()];
    });
  }
  km(lat1: number, lon1: number, lat2: number, lon2: number) {
    const rad = (v: number) => v * Math.PI / 180; const dLat = rad(lat2 - lat1), dLon = rad(lon2 - lon1);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
    return 6371 * 2 * Math.asin(Math.sqrt(a));
  }
  riskLabel(score: number) { return RISK_LABEL[score] ?? 'Low'; }
  age(ms: number) {
    const m = Math.max(0, Math.floor((Date.now() - ms) / 60_000));
    if (m < 1) return 'Just now'; if (m < 60) return `${m} min ago`;
    const h = Math.floor(m / 60); return h < 24 ? `${h}h ${m % 60}m ago` : `${Math.floor(h / 24)}d ago`;
  }
  hops(path: string) { return (path || '').split('→').map(p => p.trim()).filter(Boolean); }
}
