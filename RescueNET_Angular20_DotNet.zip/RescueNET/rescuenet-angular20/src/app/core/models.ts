export type IncidentStatus = 'Pending' | 'Dispatched' | 'Rescued';

export interface Incident {
  messageId: string; citizenId: string; latitude: number; longitude: number;
  riskScore: number; priority: number; category: string; people: number;
  note?: string | null; triageSummary?: string | null; mobilityIssue: boolean; batteryPct?: number | null;
  status: IncidentStatus; createdAtMs: number; receivedAtMs: number;
  hopPath: string; hopCount: number; gatewayId: string;
  assignedTeamId?: number | null; assignedTeamName?: string | null;
}
export interface Team { id: number; name: string; type: string; latitude: number; longitude: number; status: 'Available' | 'Busy'; }
export interface MapZone {
  id: number; name: string; type: 'Hospital' | 'Water' | 'Shelter' | 'Rescue' | 'DeadZone';
  latitude: number; longitude: number; radiusM: number; status: string; detail?: string | null; meshDevices: number;
}
export interface ActivityItem { id: number | string; timeMs: number; kind: 'info' | 'success' | 'warning' | 'critical'; title: string; detail: string; }
export interface AuthResponse { token: string; email: string; displayName: string; role: string; }
export interface UserInfo { email: string; displayName: string; role: string; }
export interface GatewayInfo { gatewayId: string; packets: number; lastSeenMs: number; avgHops: number; }

/** Packet exactly as it travels over Bluetooth and is uploaded to the server. */
export interface MeshPacket {
  messageId: string; citizenId: string; latitude: number; longitude: number;
  riskScore: number; people: number; note?: string | null; createdAtMs: number;
  hopPath: string[]; category?: string; priority?: number; batteryPct?: number | null;
}

export const RISK_LABEL: Record<number, string> = { 1: 'Low', 2: 'Moderate', 3: 'High', 4: 'Critical' };

export interface CategoryMeta { key: string; label: string; icon: string; tone: number; blurb: string; sample: string; }
export const CATEGORIES: CategoryMeta[] = [
  { key: 'Collapse', label: 'Building collapse', icon: '▚', tone: 0, blurb: 'Structure damaged or fallen. Highest network priority.', sample: 'Part of the building has collapsed, people under debris' },
  { key: 'Medical', label: 'Medical emergency', icon: '✚', tone: 1, blurb: 'Injury, bleeding, breathing trouble or urgent medicine.', sample: 'Injured person, bleeding, needs medical help' },
  { key: 'Trapped', label: 'Person trapped', icon: '⛶', tone: 2, blurb: 'Cannot leave a room, floor or vehicle safely.', sample: 'We are trapped and cannot get out' },
  { key: 'Fire', label: 'Fire or smoke', icon: '♨', tone: 3, blurb: 'Flames, smoke or an explosion nearby.', sample: 'Fire and smoke in the building' },
  { key: 'Flood', label: 'Flood water', icon: '≋', tone: 1, blurb: 'Water level rising around you. Reports are clustered into flood zones.', sample: 'Water is rising, knee level on our street' },
  { key: 'Warning', label: 'Hazard warning', icon: '⚠', tone: 2, blurb: 'Warn others about gas leaks, live wires or landslides.', sample: 'Live wire in the water near the junction, danger' },
  { key: 'Supplies', label: 'Water, food, medicine', icon: '◍', tone: 0, blurb: 'Report shortages so supplies are routed to you.', sample: 'We need food and drinking water' },
  { key: 'Safe', label: 'I’m safe', icon: '✓', tone: 1, blurb: 'Let family and responders know you are okay. Lowest priority.', sample: 'I am safe' }
];
export function categoryIcon(key: string): string { return CATEGORIES.find(c => c.key === key)?.icon ?? '✦'; }
export function categoryLabel(key: string): string { return CATEGORIES.find(c => c.key === key)?.label ?? key; }
