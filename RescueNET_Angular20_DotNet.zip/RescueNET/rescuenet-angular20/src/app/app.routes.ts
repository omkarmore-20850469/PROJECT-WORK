import { Routes } from '@angular/router';
import { LoginComponent, SignupComponent } from './auth/auth.components';
import { OverviewComponent } from './pages/overview.component';
import { SosComponent } from './pages/sos.component';
import { IncidentsComponent } from './pages/incidents.component';
import { MeshPageComponent } from './pages/mesh.component';
import { MapPageComponent } from './pages/map.component';
import { TeamsComponent } from './pages/teams.component';
import { SettingsComponent } from './pages/settings.component';
import { authGuard, guestGuard } from './core/guards';

export const routes: Routes = [
  { path: '', component: OverviewComponent, canActivate: [authGuard], title: 'Overview | RescueNET' },
  { path: 'sos', component: SosComponent, canActivate: [authGuard], title: 'Send SOS | RescueNET' },
  { path: 'incidents', component: IncidentsComponent, canActivate: [authGuard], title: 'Incidents | RescueNET' },
  { path: 'mesh', component: MeshPageComponent, canActivate: [authGuard], title: 'Mesh network | RescueNET' },
  { path: 'map', component: MapPageComponent, canActivate: [authGuard], title: 'Survival map | RescueNET' },
  { path: 'teams', component: TeamsComponent, canActivate: [authGuard], title: 'Rescue teams | RescueNET' },
  { path: 'settings', component: SettingsComponent, canActivate: [authGuard], title: 'Activity & settings | RescueNET' },
  { path: 'login', component: LoginComponent, canActivate: [guestGuard], title: 'Sign in | RescueNET' },
  { path: 'signup', component: SignupComponent, canActivate: [guestGuard], title: 'Create account | RescueNET' },
  { path: '**', redirectTo: '' }
];
