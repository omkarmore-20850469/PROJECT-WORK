import { Component } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MeshService } from '../core/mesh.service';
import { RescueStore } from '../core/store.service';
import { ApiService } from '../core/api.service';
import { API_ORIGIN, RESCUENET_PACKET_CHAR_UUID, RESCUENET_SERVICE_UUID } from '../core/config';

@Component({
  standalone: true, selector: 'app-settings', imports: [DatePipe],
  template: `
<section class="page-content">
  <div class="page-intro"><div><div class="eyebrow">DEVICE, GATEWAY & AUDIT</div><h1>Know exactly what <em>this phone is doing.</em></h1><p>Identity, offline storage, gateway upload contract and the full activity trail.</p></div></div>

  <div class="dashboard-lower even">
    <section class="panel"><div class="panel-heading"><div><div class="eyebrow">THIS DEVICE</div><h3>Identity &amp; storage</h3></div></div>
      <div class="kv"><span>Citizen ID</span><strong>{{mesh.citizenId}}</strong></div>
      <div class="kv"><span>Mesh node label</span><strong>{{mesh.self.label}}</strong></div>
      <div class="kv"><span>Account</span><strong>{{api.user()?.displayName}} · {{api.user()?.role}}</strong></div>
      <div class="kv"><span>Unsent SOS on this phone</span><strong>{{mesh.self.queue.length}}</strong></div>
      <div class="kv"><span>Delivered, waiting for cloud</span><strong>{{store.pendingCount()}}</strong></div>
      <div class="kv"><span>Cloud connection</span><strong>{{store.apiOnline() ? 'Online' : 'Unreachable'}}</strong></div>
      <div class="kv"><span>Simulated internet</span><strong>{{mesh.selfInternet() ? 'On' : 'Off (outage)'}}</strong></div>
      <div class="settings-actions"><button class="btn btn-outline" (click)="mesh.toggleSelfInternet()">{{mesh.selfInternet() ? 'Simulate outage' : 'Restore internet'}}</button>
        <button class="btn btn-outline" (click)="store.flushPending()" [disabled]="!store.pendingCount()">Sync stored packets</button>
        <button class="btn btn-outline" (click)="clear()">Clear local outbox</button></div>
    </section>
    <section class="panel"><div class="panel-heading"><div><div class="eyebrow">GATEWAY CONTRACT</div><h3>Uploading from a real phone</h3></div></div>
      <p class="ble-copy">A phone, drone or base station that has internet uploads the packets it collected. IDs are SHA-256 of <code>citizenId|createdAtMs</code>; the server re-computes them and drops duplicates and forged packets.</p>
      <pre class="code">POST {{origin}}/api/mesh-ingest/sync-payload
X-Gateway-Key: dev-gateway-key
X-Gateway-Id:  GW-MUM-01

[{{ '{' }} "messageId": "…sha256…", "citizenId": "CIT-1042",
   "latitude": 19.076, "longitude": 72.8777,
   "riskScore": 4, "priority": 97, "category": "Trapped",
   "people": 2, "note": "…", "createdAtMs": 1760000000000,
   "hopPath": ["1042","B-04","F-12"], "batteryPct": 41 {{ '}' }}]</pre></section>
  </div>

  <div class="dashboard-lower even">
    <section class="panel"><div class="panel-heading"><div><div class="eyebrow">BLUETOOTH PROTOCOL</div><h3>GATT service for native phones</h3></div></div>
      <div class="kv"><span>Service UUID</span><strong class="mono">{{svc}}</strong></div>
      <div class="kv"><span>Packet characteristic</span><strong class="mono">{{chr}}</strong></div>
      <div class="kv"><span>Properties</span><strong>Write w/o response · Notify</strong></div>
      <div class="kv"><span>Framing</span><strong>JSON + “\\n”, chunks ≤ 180 B</strong></div>
      <p class="ble-copy">Full details, advertising rules and the dedupe/ack behaviour are in <code>docs/BLE-PROTOCOL.md</code>.</p>
      <div class="safety">RescueNET is a prototype and not a certified emergency service. Keep official channels (112) available and never rely on it as the only path to rescue.</div>
    </section>
    <section class="panel"><div class="panel-heading"><div><div class="eyebrow">ACTIVITY LOG</div><h3>Command-center audit trail</h3></div></div>
      <div class="event-feed tall">
        @for (a of store.activity(); track a.id) { <div class="event" [class]="'event ev-'+a.kind"><span class="ev-dot"></span><div><strong>{{a.title}}</strong><small>{{a.detail}} · {{a.timeMs | date:'MMM d, HH:mm:ss'}}</small></div></div>
        } @empty { <div class="empty-state"><p>Activity appears once the command center is reachable.</p></div> }
      </div>
    </section>
  </div>
</section>`
})
export class SettingsComponent {
  origin = API_ORIGIN; svc = RESCUENET_SERVICE_UUID; chr = RESCUENET_PACKET_CHAR_UUID;
  constructor(public mesh: MeshService, public store: RescueStore, public api: ApiService) {}
  clear() { this.mesh.clearOutbox(); this.api.notify('Local outbox cleared.'); }
}
