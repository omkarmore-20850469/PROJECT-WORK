import { Component, OnDestroy, OnInit, computed, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CATEGORIES, categoryIcon, categoryLabel } from '../core/models';
import { MeshService } from '../core/mesh.service';
import { RescueStore } from '../core/store.service';
import { analyzeTriage } from '../core/triage';

const HOLD_MS = 2000;

@Component({
  standalone: true, selector: 'app-sos', imports: [FormsModule, RouterLink],
  template: `
<section class="page-content">
  <div class="page-intro"><div><div class="eyebrow">EMERGENCY PACKET</div><h1>Help is a few <em>hops away.</em></h1><p>Choose what is happening, add a short description and hold the button. Your phone packs location, battery and AI priority into one packet.</p></div>
    <div class="intro-badge">◉ &nbsp; WORKS WITH NO INTERNET</div></div>

  @if (!sentId()) {
    <div class="workout-layout">
      <section class="exercise-area">
        <div class="section-heading compact"><div><h3>What is happening?</h3><p>The more specific you are, the better the AI can prioritise your packet.</p></div><span class="count-chip">{{categories.length}} TYPES</span></div>
        <div class="exercise-grid">
          @for (c of categories; track c.key; let i = $index) {
            <button class="exercise-card" [class.selected]="category()===c.key" (click)="pick(c.key)">
              <div class="exercise-card-top"><span [class]="'exercise-icon tone-'+c.tone">{{c.icon}}</span><span class="select-circle">{{category()===c.key?'✓':'+'}}</span></div>
              <span class="exercise-category">PRIORITY ≈ {{base(c.key)}}</span><strong>{{c.label}}</strong><p>{{c.blurb}}</p>
            </button>
          }
        </div>

        <section class="panel sos-form">
          <div class="panel-heading"><div><div class="eyebrow">DETAILS</div><h3>Describe the situation</h3></div></div>
          <label class="field-label">Message <span class="muted-inline">({{note().length}}/280)</span></label>
          <textarea class="text-area" rows="3" maxlength="280" [ngModel]="note()" (ngModelChange)="note.set($event)" placeholder="e.g. I am trapped on the 3rd floor. My grandmother can't walk. Water is entering the building."></textarea>
          <div class="form-row">
            <div><label class="field-label">People affected</label><div class="stepper"><button type="button" (click)="people.set(max1(people()-1))">−</button><span>{{people()}}</span><button type="button" (click)="people.set(people()+1)">+</button></div></div>
            <div><label class="field-label">Latitude</label><input class="num-input" type="number" step="0.0001" [ngModel]="lat()" (ngModelChange)="lat.set(+$event)"></div>
            <div><label class="field-label">Longitude</label><input class="num-input" type="number" step="0.0001" [ngModel]="lon()" (ngModelChange)="lon.set(+$event)"></div>
          </div>
          <div class="loc-row"><button type="button" class="btn btn-outline" (click)="locate()">◎ Use my current location</button><span class="muted-inline">{{store.locationKnown() ? 'GPS location captured.' : 'Using a default area. GPS needs permission.'}}</span></div>
        </section>

        <section class="panel triage-card" [class]="'panel triage-card risk-edge-'+triage().riskScore">
          <div class="triage-top"><div><div class="eyebrow">AI TRIAGE ENGINE · RUNS ON THIS PHONE</div><h3>{{triage().severity}} · {{categoryName()}}</h3></div>
            <div class="triage-score"><strong>{{triage().priority}}</strong><small>/ 100</small></div></div>
          <div class="conf-bar big"><i [class]="'risk-bg-fill-'+triage().riskScore" [style.width.%]="triage().priority"></i></div>
          <div class="chips"><span class="chip">{{triage().people}} {{triage().people===1?'person':'people'}}</span>
            <span class="chip" [class.on]="triage().mobilityIssue">Mobility: {{triage().mobilityIssue?'limited':'no issue found'}}</span>
            @for (h of triage().hazards; track h) { <span class="chip on">{{h}}</span> }</div>
          <p class="triage-sum">{{triage().summary}}</p>
        </section>

        <div class="sos-hold-wrap">
          <button class="sos-hold" [style.--p]="holdPct()+'%'" [class.holding]="holdPct()>0" [disabled]="sending()"
            (pointerdown)="startHold($event)" (pointerup)="cancelHold()" (pointerleave)="cancelHold()" (pointercancel)="cancelHold()"
            (keydown)="keyDown($event)" (keyup)="cancelHold()" (contextmenu)="$event.preventDefault()" aria-label="Hold for two seconds to send SOS">
            <span class="sos-core"><strong>SOS</strong><small>{{holdPct()>0 ? 'KEEP HOLDING…' : 'HOLD 2 SECONDS'}}</small></span></button>
          <div class="sos-side"><div class="eyebrow">OR WITHOUT HOLDING</div><button class="btn btn-primary" [disabled]="sending()" (click)="send()">{{sending()?'Packing packet…':'Send SOS now'}} <span>→</span></button>
            <p class="muted-inline">Packet carries GPS, time, battery ({{battery()??'n/a'}}{{battery()!=null?'%':''}}), your note and priority. It is stored here until forwarded.</p></div>
        </div>
      </section>

      <aside class="workout-aside">
        <div class="aside-illustration"><div class="aside-sun"></div><div class="aside-shape">✚</div><div class="aside-caption">STAY CALM · HELP IS ROUTING</div></div>
        <div class="aside-copy"><div class="eyebrow">WHAT HAPPENS NEXT</div><h3>Phone to phone to rescue.</h3><p>Your packet hops across nearby RescueNET phones until one has internet and uploads it.</p><div class="aside-rule"></div>
          <div class="aside-tip"><span>01</span><div><strong>Stored safely</strong><small>Kept on your phone until a relay accepts it.</small></div></div>
          <div class="aside-tip"><span>02</span><div><strong>Critical goes first</strong><small>Higher priority packets overtake chatter in every queue.</small></div></div>
          <div class="aside-tip"><span>03</span><div><strong>Never lost</strong><small>If a phone leaves, another route is chosen.</small></div></div>
          <div class="aside-tip"><span>04</span><div><strong>Also call 112</strong><small>Use official services whenever they are reachable.</small></div></div></div>
      </aside>
    </div>
  } @else {
    <div class="active-workout panel">
      <div class="active-top"><span class="live-pill" [class.done]="delivered()"><span class="pulse"></span> {{delivered()?'DELIVERED TO COMMAND CENTER':'TRANSMITTING THROUGH THE MESH'}}</span><button class="text-button" (click)="reset()">Send another ×</button></div>
      <div class="active-main">
        <div class="progress-ring" [style.--progress]="progress()+'%'"><div><strong>{{progress()}}%</strong><small>{{delivered()?'DELIVERED':'IN TRANSIT'}}</small></div></div>
        <div class="active-details">
          <div class="eyebrow">{{delivered() ? 'HELP HAS BEEN NOTIFIED' : 'YOUR PACKET IS MOVING'}}</div>
          <h2>{{categoryName()}} · P{{sentPriority()}}</h2>
          <p>{{delivered() ? 'Rescue coordinators can now see your location and message.' : 'Stay where you are if it is safe. Keep this screen open.'}}</p>
          <div class="path-line">@for (h of path(); track $index) { <span class="hop" [class.origin]="$first" [class.gw]="$last && journey()?.delivered">{{h}}</span> @if (!$last) { <i>→</i> } }</div>
          <div class="active-actions"><a class="btn btn-primary" routerLink="/mesh">Watch it on the mesh <span>⌁</span></a><a class="btn btn-outline" routerLink="/incidents">View in incidents</a></div>
        </div>
      </div>
      <div class="steps">
        @for (s of steps(); track s.title) { <div class="step" [class.done]="s.done"><span class="step-dot">{{s.done?'✓':'…'}}</span><div><strong>{{s.title}}</strong><small>{{s.detail}}</small></div></div> }
      </div>
    </div>
  }
</section>`
})
export class SosComponent implements OnInit, OnDestroy {
  categories = CATEGORIES;
  category = signal('Trapped'); note = signal(''); people = signal(1);
  lat = signal(19.076); lon = signal(72.8777); battery = signal<number | null>(null);
  holdPct = signal(0); sentId = signal<string | null>(null); sending = signal(false); sentPriority = signal(0);
  private holdTimer: any; private holdStart = 0; private lastSample = '';

  constructor(public store: RescueStore, private mesh: MeshService, private route: ActivatedRoute) {}

  triage = computed(() => analyzeTriage(this.note(), this.category(), this.people()));
  journey = computed(() => { const id = this.sentId(); return id ? this.mesh.journey()[id] : undefined; });
  path = computed(() => this.journey()?.path ?? [this.mesh.self.label]);
  delivered = computed(() => {
    const id = this.sentId(); if (!id) return false;
    return this.store.uploaded().has(id) || this.store.incidents().some(i => i.messageId === id && i.gatewayId !== 'LOCAL' && i.gatewayId !== 'BLE-LOCAL');
  });
  steps = computed(() => {
    const j = this.journey(); const hops = (j?.path.length ?? 1) - 1; const direct = this.mesh.selfInternet();
    return [
      { title: 'Stored on this phone', detail: 'Written to local storage so it survives a restart.', done: true },
      { title: 'Handed to relay phones', detail: hops > 0 ? `${hops} hop${hops === 1 ? '' : 's'}: ${j!.path.join(' → ')}` : direct ? 'Not needed — this phone has internet and is its own gateway.' : 'Searching for a route…', done: hops > 0 || direct },
      { title: 'Reached a gateway', detail: j?.gateway ? `Gateway ${j.gateway} has the packet.` : 'Waiting for a phone with internet.', done: !!j?.delivered },
      { title: 'Received by command center', detail: this.delivered() ? 'Visible to responders, with its full relay path.' : (j?.delivered ? 'Uploading… will retry automatically if the cloud is unreachable.' : 'Pending.'), done: this.delivered() }
    ];
  });
  progress = computed(() => {
    if (this.delivered()) return 100;
    const done = this.steps().filter(s => s.done).length; const hops = Math.max(0, (this.journey()?.path.length ?? 1) - 1);
    return Math.min(95, done * 25 + (done < 3 ? Math.min(20, hops * 6) : 0));
  });

  ngOnInit() {
    this.lat.set(this.store.location().latitude); this.lon.set(this.store.location().longitude);
    void this.store.batteryPct().then(b => this.battery.set(b));
    const cat = this.route.snapshot.queryParamMap.get('cat'); if (cat && CATEGORIES.some(c => c.key === cat)) this.pick(cat);
  }
  ngOnDestroy() { clearInterval(this.holdTimer); }

  base(key: string) { return analyzeTriage('', key, 1).priority; }
  categoryName() { return categoryLabel(this.triage().category); }
  max1(n: number) { return Math.max(1, n); }
  icon = categoryIcon;

  pick(key: string) {
    this.category.set(key);
    const sample = CATEGORIES.find(c => c.key === key)?.sample ?? '';
    if (!this.note().trim() || this.note() === this.lastSample) { this.note.set(sample); this.lastSample = sample; }
  }
  async locate() { await this.store.locate(); const l = this.store.location(); this.lat.set(l.latitude); this.lon.set(l.longitude); }

  startHold(e: Event) { e.preventDefault(); if (this.holdTimer || this.sending()) return; this.holdStart = Date.now();
    this.holdTimer = setInterval(() => { const pct = Math.min(100, ((Date.now() - this.holdStart) / HOLD_MS) * 100); this.holdPct.set(Math.round(pct)); if (pct >= 100) { this.cancelHold(false); void this.send(); } }, 30); }
  keyDown(e: KeyboardEvent) { if ((e.key === ' ' || e.key === 'Enter') && !e.repeat) this.startHold(e); }
  cancelHold(reset = true) { clearInterval(this.holdTimer); this.holdTimer = undefined; if (reset) this.holdPct.set(0); }

  async send() {
    if (this.sending()) return; this.sending.set(true);
    try {
      const batteryPct = this.battery() ?? await this.store.batteryPct();
      const id = await this.store.submitSos({ category: this.category(), note: this.note(), people: this.people(), latitude: this.lat(), longitude: this.lon(), batteryPct });
      this.sentPriority.set(this.triage().priority); this.sentId.set(id); navigator.vibrate?.(180);
    } finally { this.sending.set(false); this.holdPct.set(0); }
  }
  reset() { this.sentId.set(null); this.note.set(''); this.lastSample = ''; this.people.set(1); this.holdPct.set(0); }
}
