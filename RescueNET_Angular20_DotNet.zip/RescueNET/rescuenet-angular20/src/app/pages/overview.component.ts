import { Component, computed } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MeshService } from '../core/mesh.service';
import { RescueStore } from '../core/store.service';
import { categoryIcon, categoryLabel } from '../core/models';

@Component({
  standalone: true, selector: 'app-overview', imports: [RouterLink, DecimalPipe],
  template: `
<section class="page-content">
  <div class="hero-banner">
    <div class="hero-content">
      <div class="pill-label"><span class="pulse"></span> MESH ACTIVE · {{nearby()}} DEVICES NEARBY</div>
      <h1>When the network fails,<br><em>the phones don’t.</em></h1>
      <p>Your phone discovers nearby RescueNET users and forwards emergency messages hop by hop until they reach someone with a connection.</p>
      <div class="hero-actions"><a class="btn btn-light" routerLink="/sos">Send an SOS <span>✚</span></a><a class="btn btn-ghost" routerLink="/mesh">Open live mesh <span>⌁</span></a></div>
    </div>
    <div class="hero-art"><div class="orb orb-one"></div><div class="orb orb-two"></div><div class="hero-ring"><div class="hero-glyph">◉</div></div>
      <div class="floating-card"><span>⌁</span><div><strong>{{mesh.stats().gateways}} gateway{{mesh.stats().gateways===1?'':'s'}} reachable</strong><small>{{mesh.stats().links}} radio links in range</small></div></div></div>
    <div class="hero-index">RESCUENET / 001</div>
  </div>

  <div class="section-heading"><div><div class="eyebrow">LIVE SITUATION</div><h3>What is happening around you</h3></div><a routerLink="/incidents" class="text-link">View incidents <span>→</span></a></div>
  <div class="stats-grid four">
    <article class="stat-card"><div class="stat-top"><span class="stat-icon lilac">⌁</span><span class="stat-tag">MESH</span></div><div class="stat-value">{{nearby()}}<small> phones</small></div><div class="stat-label">Devices in range</div><div class="stat-bottom"><span class="mini-line">╱╲╱╱╲</span><span>{{mesh.stats().links}} links · {{mesh.stats().ble}} real Bluetooth</span></div></article>
    <article class="stat-card"><div class="stat-top"><span class="stat-icon peach">✚</span><span class="stat-tag">OPEN</span></div><div class="stat-value">{{store.stats().open}}<small> SOS</small></div><div class="stat-label">Active emergencies</div><div class="stat-bottom"><span class="stat-dot peach-dot"></span><span>{{store.stats().pending}} waiting · {{store.stats().dispatched}} dispatched</span></div></article>
    <article class="stat-card"><div class="stat-top"><span class="stat-icon rose">⚠</span><span class="stat-tag">PRIORITY 90+</span></div><div class="stat-value">{{store.stats().critical}}<small> critical</small></div><div class="stat-label">Need rescue first</div><div class="stat-bottom"><span class="stat-dot rose-dot"></span><span>{{store.stats().people}} people affected</span></div></article>
    <article class="stat-card"><div class="stat-top"><span class="stat-icon mint">⇄</span><span class="stat-tag">THIS SESSION</span></div><div class="stat-value">{{mesh.stats().delivered}}<small> delivered</small></div><div class="stat-label">Packets sent through the mesh</div><div class="stat-bottom"><span class="stat-dot mint-dot"></span><span>{{mesh.stats().duplicates}} duplicates dropped · {{mesh.stats().reroutes}} reroutes</span></div></article>
  </div>

  <div class="dashboard-lower">
    <section class="panel recent-panel">
      <div class="panel-heading"><div><div class="eyebrow">PRIORITY QUEUE</div><h3>Most critical first</h3></div><a routerLink="/incidents" class="circle-link">↗</a></div>
      @if (top().length) {
        <div class="recent-list">
          @for (i of top(); track i.messageId) {
            <div class="recent-row">
              <div class="exercise-avatar" [class]="'exercise-avatar risk-bg-'+i.riskScore">{{icon(i.category)}}</div>
              <div class="recent-info"><strong>{{label(i.category)}} · {{i.citizenId}}</strong><small>{{store.age(i.createdAtMs)}} · {{i.hopCount}} hop{{i.hopCount===1?'':'s'}} · {{i.people}} {{i.people===1?'person':'people'}}</small></div>
              <span class="prio-pill" [class]="'prio-pill risk-'+i.riskScore">P{{i.priority}}</span>
            </div>
          }
        </div>
      } @else {
        <div class="empty-state"><div class="empty-icon">◉</div><strong>No active emergencies.</strong><p>Incoming SOS packets will appear here, ranked by AI priority.</p><a routerLink="/sos" class="text-link">Send a test SOS →</a></div>
      }
    </section>
    <section class="panel nudge-panel">
      <div class="nudge-art"><span>✚</span><div class="nudge-circle"></div></div>
      <div class="eyebrow">NEED HELP?</div>
      <h3>Hold SOS.<br>The mesh does the rest.</h3>
      <p>Your location, battery level and a short description are packed into one packet and passed phone to phone.</p>
      <a routerLink="/sos" class="btn btn-primary btn-full">Open SOS screen <span>→</span></a>
      <a routerLink="/sos" [queryParams]="{cat:'Safe'}" class="btn btn-outline btn-full" style="margin-top:8px">I’m safe — tell my family <span>✓</span></a>
      <div class="nudge-foot">KEEP 112 AVAILABLE AS WELL.</div>
    </section>
  </div>

  <div class="dashboard-lower even">
    <section class="panel">
      <div class="panel-heading"><div><div class="eyebrow">NEARBY</div><h3>Safe zones &amp; supplies</h3></div><a routerLink="/map" class="circle-link">↗</a></div>
      <div class="recent-list">
        @for (n of store.nearby().slice(0,4); track n.zone.id) {
          <div class="recent-row"><div class="exercise-avatar">{{zoneIcon(n.zone.type)}}</div><div class="recent-info"><strong>{{n.zone.name}}</strong><small>{{n.zone.detail}}</small></div><span class="calorie-pill">{{dist(n.km)}}</span><span class="status-pill" [class.cancelled]="n.zone.status!=='Open'">{{n.zone.status}}</span></div>
        } @empty { <div class="empty-state"><p>Map data loads once the command center is reachable.</p></div> }
      </div>
    </section>
    <section class="panel">
      <div class="panel-heading"><div><div class="eyebrow">INFRASTRUCTURE SENSING</div><h3>Phones as network sensors</h3></div><a routerLink="/map" class="circle-link">↗</a></div>
      <div class="insight-list">
        @for (z of store.deadZones(); track z.id) {
          <div class="insight"><span class="insight-dot rose-dot"></span><div><strong>Internet unavailable · {{area(z.radiusM) | number:'1.1-1'}} km²</strong><small>{{z.name}}: {{z.meshDevices}} RescueNET devices still active inside it.</small></div></div>
        }
        @for (f of store.floodZones(); track $index) {
          <div class="insight"><span class="insight-dot blue-dot"></span><div><strong>Flood zone detected · {{f.confidence}}% confidence</strong><small>{{f.reports}} independent reports clustered within 600 m · updated {{store.age(f.lastMs)}}.</small>
            <div class="conf-bar"><i [style.width.%]="f.confidence"></i></div></div></div>
        }
        @if (!store.deadZones().length && !store.floodZones().length) { <div class="empty-state"><p>No dead zones or flood clusters detected yet.</p></div> }
      </div>
    </section>
  </div>
</section>`
})
export class OverviewComponent {
  constructor(public store: RescueStore, public mesh: MeshService) {}
  nearby = computed(() => Math.max(0, this.mesh.stats().online - 1));
  top = computed(() => this.store.queue().slice(0, 5));
  icon = categoryIcon; label = categoryLabel;
  zoneIcon(t: string) { return t === 'Hospital' ? '✚' : t === 'Water' ? '◍' : t === 'Shelter' ? '⌂' : t === 'Rescue' ? '☷' : '◌'; }
  dist(km: number) { return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`; }
  area(radiusM: number) { return Math.PI * (radiusM / 1000) ** 2; }
}
