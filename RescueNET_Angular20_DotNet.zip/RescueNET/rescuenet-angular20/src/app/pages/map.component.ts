import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, effect, signal } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import * as L from 'leaflet';
import { RescueStore } from '../core/store.service';
import { categoryLabel } from '../core/models';

const RISK_COLOR: Record<number, string> = { 1: '#3f9d7a', 2: '#e0a526', 3: '#e8801a', 4: '#d6455d' };

@Component({
  standalone: true, selector: 'app-map-page', imports: [DecimalPipe],
  template: `
<section class="page-content">
  <div class="page-intro"><div><div class="eyebrow">LIVE SURVIVAL MAP</div><h1>What is happening <em>right now.</em></h1><p>Not navigation — situational awareness. Reports are clustered into flood zones, dead zones show where the internet has failed, and safe zones show where to go.</p></div>
    <div class="intro-badge">◎ &nbsp; {{store.incidents().length}} REPORTS</div></div>

  <div class="map-layout">
    <section class="panel map-panel">
      <div class="map-toolbar">
        <button class="chip-btn" [class.on]="showSos()" (click)="showSos.set(!showSos())">● SOS reports</button>
        <button class="chip-btn" [class.on]="showFlood()" (click)="showFlood.set(!showFlood())">≋ Flood zones</button>
        <button class="chip-btn" [class.on]="showDead()" (click)="showDead.set(!showDead())">◌ Dead zones</button>
        <button class="chip-btn" [class.on]="showPlaces()" (click)="showPlaces.set(!showPlaces())">✚ Safe zones</button>
        <button class="chip-btn" [class.on]="showTeams()" (click)="showTeams.set(!showTeams())">☷ Rescue teams</button>
      </div>
      <div class="leaflet-host" #host></div>
      @if (tilesFailed()) { <div class="map-note">Map tiles need an internet connection. Markers and zones still draw offline.</div> }
    </section>
    <aside class="map-side">
      <section class="panel"><div class="eyebrow">AI CLUSTERING</div><h3 class="side-h">Flood detection</h3>
        @for (f of store.floodZones(); track $index) {
          <div class="insight"><span class="insight-dot blue-dot"></span><div><strong>🌊 Flood zone detected</strong><small>{{f.reports}} independent reports · updated {{store.age(f.lastMs)}}</small>
            <div class="conf-row"><span>Flood probability</span><b>{{f.confidence}}%</b></div><div class="conf-bar"><i [style.width.%]="f.confidence"></i></div></div></div>
        } @empty { <p class="muted-inline">Needs 3 or more flood reports within 600 m.</p> }
      </section>
      <section class="panel"><div class="eyebrow">DEAD-ZONE PREDICTION</div><h3 class="side-h">Where internet is gone</h3>
        @for (z of store.deadZones(); track z.id) {
          <div class="insight"><span class="insight-dot rose-dot"></span><div><strong>{{z.name}}</strong><small>No internet across {{area(z.radiusM) | number:'1.1-1'}} km², yet {{z.meshDevices}} RescueNET devices are active there.</small></div></div>
        } @empty { <p class="muted-inline">No dead zones reported.</p> }
      </section>
      <section class="panel"><div class="eyebrow">NEAREST HELP</div><h3 class="side-h">Safe zones &amp; supplies</h3>
        @for (n of store.nearby().slice(0,5); track n.zone.id) {
          <div class="insight"><span class="insight-dot" [class.rose-dot]="n.zone.status!=='Open'" [class.mint-dot]="n.zone.status==='Open'"></span><div><strong>{{n.zone.name}}</strong><small>{{dist(n.km)}} · {{n.zone.status}} · {{n.zone.detail}}</small></div></div>
        }
      </section>
    </aside>
  </div>
</section>`
})
export class MapPageComponent implements AfterViewInit, OnDestroy {
  @ViewChild('host', { static: true }) host!: ElementRef<HTMLDivElement>;
  showSos = signal(true); showFlood = signal(true); showDead = signal(true); showPlaces = signal(true); showTeams = signal(true);
  tilesFailed = signal(false);
  private map?: L.Map; private layer = L.layerGroup(); private ready = signal(false); private ro?: ResizeObserver;

  constructor(public store: RescueStore) {
    effect(() => {
      const data = { inc: this.store.incidents(), teams: this.store.teams(), zones: this.store.zones(), flood: this.store.floodZones(),
        s: this.showSos(), f: this.showFlood(), d: this.showDead(), p: this.showPlaces(), t: this.showTeams(), loc: this.store.location(), ready: this.ready() };
      if (data.ready) this.draw(data);
    });
  }

  ngAfterViewInit() {
    const loc = this.store.location();
    this.map = L.map(this.host.nativeElement, { zoomControl: true }).setView([loc.latitude, loc.longitude], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '© OpenStreetMap contributors' })
      .on('tileerror', () => this.tilesFailed.set(true)).addTo(this.map);
    this.layer.addTo(this.map);
    this.ro = new ResizeObserver(() => this.map?.invalidateSize({ pan: false })); this.ro.observe(this.host.nativeElement);
    setTimeout(() => this.map?.invalidateSize(), 150);
    this.ready.set(true);
  }
  ngOnDestroy() { this.ro?.disconnect(); this.map?.remove(); }

  area(r: number) { return Math.PI * (r / 1000) ** 2; }
  dist(km: number) { return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`; }

  private esc(s: string) { return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string)); }

  private draw(d: { inc: any[]; teams: any[]; zones: any[]; flood: any[]; s: boolean; f: boolean; d: boolean; p: boolean; t: boolean; loc: { latitude: number; longitude: number } }) {
    if (!this.map) return;
    this.layer.clearLayers();
    if (d.d) d.zones.filter(z => z.type === 'DeadZone').forEach(z =>
      L.circle([z.latitude, z.longitude], { radius: z.radiusM, color: '#d6455d', weight: 1.5, dashArray: '6 6', fillColor: '#d6455d', fillOpacity: 0.08 })
        .bindTooltip(`<strong>${this.esc(z.name)}</strong><br>No internet · ${z.meshDevices} mesh devices active`).addTo(this.layer));
    if (d.f) d.flood.forEach(f =>
      L.circle([f.latitude, f.longitude], { radius: 420, color: '#3b82f6', weight: 1.5, fillColor: '#3b82f6', fillOpacity: 0.2 })
        .bindTooltip(`<strong>Flood zone</strong><br>${f.reports} reports · ${f.confidence}% confidence`).addTo(this.layer));
    if (d.p) d.zones.filter(z => z.type !== 'DeadZone').forEach(z => {
      const glyph = z.type === 'Hospital' ? '✚' : z.type === 'Water' ? '◍' : z.type === 'Shelter' ? '⌂' : '☷';
      L.marker([z.latitude, z.longitude], { icon: L.divIcon({ className: `zone-pin zp-${z.type.toLowerCase()} ${z.status !== 'Open' ? 'zp-bad' : ''}`, html: glyph, iconSize: [26, 26] }) })
        .bindTooltip(`<strong>${this.esc(z.name)}</strong><br>${z.status} · ${this.esc(z.detail ?? '')}`).addTo(this.layer);
    });
    if (d.t) d.teams.forEach(t =>
      L.marker([t.latitude, t.longitude], { icon: L.divIcon({ className: `team-pin ${t.status === 'Busy' ? 'busy' : ''}`, html: '☷', iconSize: [26, 26] }) })
        .bindTooltip(`${this.esc(t.name)} (${t.status})`).addTo(this.layer));
    if (d.s) [...d.inc].filter(i => i.status !== 'Rescued').sort((a, b) => a.priority - b.priority).forEach(i =>
      L.circleMarker([i.latitude, i.longitude], { radius: 5 + i.riskScore * 2, color: '#fff', weight: 1.5, fillColor: RISK_COLOR[i.riskScore] ?? '#999', fillOpacity: i.status === 'Pending' ? 0.92 : 0.45 })
        .bindTooltip(`<strong>${categoryLabel(i.category)}</strong> · P${i.priority}<br>${i.people} ${i.people === 1 ? 'person' : 'people'} · ${i.status}<br>${this.esc(i.note ?? '')}`).addTo(this.layer));
    L.circleMarker([d.loc.latitude, d.loc.longitude], { radius: 7, color: '#fff', weight: 2.5, fillColor: '#7161d8', fillOpacity: 1 }).bindTooltip('You are here').addTo(this.layer);
  }
}
