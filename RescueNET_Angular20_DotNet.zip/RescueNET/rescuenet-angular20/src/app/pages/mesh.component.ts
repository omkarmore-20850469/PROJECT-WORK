import { Component } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MeshCanvasComponent } from '../shared/mesh-canvas.component';
import { MeshService } from '../core/mesh.service';
import { RescueStore } from '../core/store.service';
import { ApiService } from '../core/api.service';

@Component({
  standalone: true, selector: 'app-mesh-page', imports: [MeshCanvasComponent, DatePipe, RouterLink],
  template: `
<section class="page-content">
  <div class="page-intro"><div><div class="eyebrow">BLUETOOTH MESH</div><h1>Watch the phones <em>work together.</em></h1><p>Phones are nodes, radio range forms the links, and every glowing pulse is an emergency packet hopping toward a gateway.</p></div>
    <div class="intro-badge">⌁ &nbsp; {{mesh.stats().links}} LINKS · {{mesh.stats().gateways}} GATEWAYS</div></div>

  <div class="mesh-controls">
    <button class="btn btn-primary" (click)="testSos()">Send test SOS <span>✚</span></button>
    <button class="btn btn-outline" (click)="mesh.addNode()">＋ Add phone</button>
    <button class="btn btn-outline" (click)="mesh.dropNode()">Move a phone out of range</button>
    <button class="btn btn-outline" (click)="mesh.restoreAll()">Restore all</button>
    <button class="switch" [class.on]="mesh.selfInternet()" (click)="mesh.toggleSelfInternet()" role="switch" [attr.aria-checked]="mesh.selfInternet()"><i></i>{{mesh.selfInternet()?'This phone has internet':'This phone is offline'}}</button>
    <button class="btn btn-outline ble-btn" (click)="connectBle()" [disabled]="!mesh.bleSupported || connecting">{{connecting?'Waiting for device…':'⌁ Connect Bluetooth device'}}</button>
  </div>

  <section class="panel mesh-panel"><app-mesh-canvas [height]="470" /></section>

  <div class="stats-grid four" style="margin-top:15px">
    <article class="stat-card"><div class="stat-top"><span class="stat-icon lilac">⌁</span><span class="stat-tag">NODES</span></div><div class="stat-value">{{mesh.stats().online}}<small> / {{mesh.stats().nodes}} online</small></div><div class="stat-label">Phones in the mesh</div></article>
    <article class="stat-card"><div class="stat-top"><span class="stat-icon peach">⇢</span><span class="stat-tag">TRAFFIC</span></div><div class="stat-value">{{mesh.stats().inFlight}}<small> in flight</small></div><div class="stat-label">{{mesh.stats().queued}} stored in phone queues</div></article>
    <article class="stat-card"><div class="stat-top"><span class="stat-icon mint">✓</span><span class="stat-tag">DELIVERED</span></div><div class="stat-value">{{mesh.stats().delivered}}<small> packets</small></div><div class="stat-label">{{mesh.stats().forwarded}} hops forwarded</div></article>
    <article class="stat-card"><div class="stat-top"><span class="stat-icon rose">⟲</span><span class="stat-tag">RELIABILITY</span></div><div class="stat-value">{{mesh.stats().reroutes}}<small> reroutes</small></div><div class="stat-label">{{mesh.stats().duplicates}} duplicate packets dropped</div></article>
  </div>

  <div class="dashboard-lower even">
    <section class="panel">
      <div class="panel-heading"><div><div class="eyebrow">NODES</div><h3>Phones &amp; gateways</h3></div></div>
      <div class="table-wrap short"><table><thead><tr><th>NODE</th><th>ROLE</th><th>LINKS</th><th>QUEUE</th><th>RELAYED</th><th>BATTERY</th></tr></thead><tbody>
        @for (n of mesh.view(); track n.id) {
          <tr><td><strong class="cell-strong">{{n.label}}</strong></td><td><span class="status-pill" [class.cancelled]="!n.online">{{n.online ? roleName(n.type) : 'out of range'}}</span></td><td>{{n.links}}</td><td>{{n.queue}}</td><td>{{n.relayed}}</td><td>{{n.type==='ble' && !n.battery ? '—' : n.battery+'%'}}</td></tr>
        }</tbody></table></div>
    </section>
    <section class="panel">
      <div class="panel-heading"><div><div class="eyebrow">LIVE PACKET LOG</div><h3>What the mesh is doing</h3></div></div>
      <div class="event-feed">
        @for (e of mesh.events(); track e.id) { <div class="event" [class]="'event ev-'+e.kind"><span class="ev-dot"></span><div><strong>{{e.text}}</strong><small>{{e.time | date:'HH:mm:ss'}}</small></div></div>
        } @empty { <div class="empty-state"><p>Send a test SOS to watch packets travel.</p></div> }
      </div>
    </section>
  </div>

  <section class="panel ble-panel">
    <div class="panel-heading"><div><div class="eyebrow">REAL BLUETOOTH</div><h3>Connect actual devices</h3></div></div>
    @if (!mesh.bleSupported) { <p class="warn">Web Bluetooth is not available in this browser. Open RescueNET in Chrome or Edge (desktop or Android) on https or localhost.</p> }
    <p class="ble-copy">The button above opens your browser’s Bluetooth chooser. A selected device becomes a real node. If it exposes the RescueNET GATT service (see <a routerLink="/settings" class="text-link">settings</a>), your SOS packets are written to it and its packets are received here. A web page can connect to devices but cannot advertise or relay in the background — that part is done by the native Android app.</p>
    @if (mesh.bleNodes.length) {
      <div class="recent-list">@for (b of mesh.bleNodes; track b.id) {
        <div class="recent-row"><div class="exercise-avatar">⌁</div><div class="recent-info"><strong>{{b.label}}</strong><small>{{b.online ? (b.char ? 'RescueNET service connected' : 'Connected · plain Bluetooth neighbour') : 'Disconnected'}}</small></div><button class="btn btn-outline small" (click)="mesh.disconnectBle(b)">Remove</button></div>
      }</div>
    }
  </section>
</section>`
})
export class MeshPageComponent {
  connecting = false;
  constructor(public mesh: MeshService, private store: RescueStore, private api: ApiService) {}
  roleName(t: string) { return t === 'self' ? 'this phone' : t === 'gateway' ? 'gateway' : t === 'ble' ? 'bluetooth' : 'relay'; }
  async testSos() {
    const l = this.store.location();
    await this.store.submitSos({ category: 'Trapped', note: 'Test: trapped on an upper floor, elderly relative cannot walk, water rising.', people: 2, latitude: l.latitude, longitude: l.longitude, batteryPct: await this.store.batteryPct() });
  }
  async connectBle() {
    this.connecting = true;
    try { this.api.notify(await this.mesh.connectBle()); } catch (e: any) { this.api.notify(e.message); } finally { this.connecting = false; }
  }
}
