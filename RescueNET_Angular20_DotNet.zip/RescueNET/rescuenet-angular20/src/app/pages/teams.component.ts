import { Component, computed } from '@angular/core';
import { RouterLink } from '@angular/router';
import { RescueStore } from '../core/store.service';
import { Incident, Team, categoryLabel } from '../core/models';

@Component({
  standalone: true, selector: 'app-teams', imports: [RouterLink],
  template: `
<section class="page-content">
  <div class="page-intro"><div><div class="eyebrow">FIELD READINESS</div><h1>The right team, <em>to the right SOS.</em></h1><p>Dispatch sends the nearest available team. Marking an incident rescued releases the team automatically.</p></div>
    <a routerLink="/incidents" class="btn btn-primary">Open incident queue <span>→</span></a></div>

  <div class="history-summary">
    <div><span class="summary-icon mint">☷</span><div><strong>{{free()}}</strong><small>Teams available</small></div></div>
    <div><span class="summary-icon peach">⚑</span><div><strong>{{busy()}}</strong><small>Teams on mission</small></div></div>
    <div><span class="summary-icon rose">⚠</span><div><strong>{{waiting()}}</strong><small>SOS waiting for a team</small></div></div>
  </div>

  <div class="section-heading compact"><div><h3>Rescue teams</h3><p>{{target() ? 'Next in line: ' + label(target()!.category) + ' · P' + target()!.priority + ' · ' + target()!.citizenId : 'No SOS is waiting for dispatch.'}}</p></div><span class="count-chip">{{store.teams().length}} TEAMS</span></div>
  <div class="exercise-grid three">
    @for (t of store.teams(); track t.id; let i = $index) {
      <article class="exercise-card team-card" [class.selected]="t.status==='Available'">
        <div class="exercise-card-top"><span [class]="'exercise-icon tone-'+(i%4)">{{icon(t.type)}}</span><span class="status-pill" [class.cancelled]="t.status==='Busy'">{{t.status}}</span></div>
        <span class="exercise-category">{{t.type.toUpperCase()}}</span><strong>{{t.name}}</strong>
        <p>{{missionFor(t)}}</p>
        <div class="exercise-meta"><span>◎ {{t.latitude.toFixed(3)}}, {{t.longitude.toFixed(3)}}</span>@if (target()) { <span>⇢ {{distTo(t)}}</span> }</div>
        @if (t.status==='Available' && target()) { <button class="btn btn-primary btn-full card-btn" (click)="store.dispatch(target()!.messageId, t.id)">Dispatch to P{{target()!.priority}} <span>→</span></button> }
      </article>
    } @empty { <div class="loading-state">Teams load once the command center is reachable.</div> }
  </div>

  <section class="panel" style="margin-top:18px"><div class="panel-heading"><div><div class="eyebrow">ACTIVE MISSIONS</div><h3>Assigned incidents</h3></div></div>
    @for (i of missions(); track i.messageId) {
      <div class="recent-row"><div class="exercise-avatar">☷</div><div class="recent-info"><strong>{{i.assignedTeamName}} → {{label(i.category)}}</strong><small>{{i.citizenId}} · {{i.people}} people · P{{i.priority}} · {{store.age(i.createdAtMs)}}</small></div><button class="btn btn-outline small" (click)="store.markRescued(i.messageId)">Mark rescued ✓</button></div>
    } @empty { <div class="empty-state"><p>No teams are on a mission right now.</p></div> }
  </section>
</section>`
})
export class TeamsComponent {
  constructor(public store: RescueStore) {}
  free = computed(() => this.store.teams().filter(t => t.status === 'Available').length);
  busy = computed(() => this.store.teams().filter(t => t.status === 'Busy').length);
  waiting = computed(() => this.store.queue().filter(i => i.status === 'Pending').length);
  target = computed<Incident | null>(() => this.store.queue().find(i => i.status === 'Pending') ?? null);
  missions = computed(() => this.store.incidents().filter(i => i.status === 'Dispatched'));
  label = categoryLabel;
  icon(type: string) { return type.includes('Medical') ? '✚' : type.includes('Water') ? '≋' : type.includes('Fire') ? '♨' : type.includes('Volunteer') ? '♡' : '☷'; }
  missionFor(t: Team) { const m = this.store.incidents().find(i => i.assignedTeamId === t.id && i.status === 'Dispatched'); return m ? `On mission: ${categoryLabel(m.category)} for ${m.citizenId}.` : 'Standing by for the next dispatch.'; }
  distTo(t: Team) { const i = this.target(); if (!i) return ''; const km = this.store.km(t.latitude, t.longitude, i.latitude, i.longitude); return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`; }
}
