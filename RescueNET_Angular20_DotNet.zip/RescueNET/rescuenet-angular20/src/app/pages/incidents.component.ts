import { Component, computed, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { RescueStore } from '../core/store.service';
import { ApiService } from '../core/api.service';
import { categoryIcon, categoryLabel } from '../core/models';

@Component({
  standalone: true, selector: 'app-incidents', imports: [FormsModule, RouterLink, DatePipe],
  template: `
<section class="page-content">
  <div class="page-intro"><div><div class="eyebrow">LIVE COMMAND CENTER</div><h1>Every SOS, <em>ranked.</em></h1><p>Incoming packets, their AI priority, their location and the exact path they travelled through the mesh.</p></div>
    <div class="intro-actions"><button class="btn btn-outline" (click)="store.simulateGateway(12)">Test gateway sync</button><a routerLink="/sos" class="btn btn-primary">New SOS <span>→</span></a></div></div>

  <div class="history-summary four">
    <div><span class="summary-icon peach">✚</span><div><strong>{{store.stats().open}}</strong><small>Open emergencies</small></div></div>
    <div><span class="summary-icon rose">⚠</span><div><strong>{{store.stats().critical}}</strong><small>Critical now</small></div></div>
    <div><span class="summary-icon lilac">⌁</span><div><strong>{{store.stats().avgHops.toFixed(1)}}</strong><small>Average mesh hops</small></div></div>
    <div><span class="summary-icon mint">✓</span><div><strong>{{store.stats().rescued}}</strong><small>Rescued</small></div></div>
  </div>

  <div class="workout-layout">
    <section class="panel history-panel">
      <div class="panel-heading"><div><div class="eyebrow">PRIORITY QUEUE</div><h3>Incident list</h3></div>
        <div class="filters"><input class="search-input" [ngModel]="filter()" (ngModelChange)="filter.set($event)" placeholder="⌕  Search ID, note, gateway…">
          <select class="select-input" [ngModel]="risk()" (ngModelChange)="risk.set($event)"><option>All risks</option><option>Critical</option><option>High</option><option>Moderate</option><option>Low</option></select>
          <select class="select-input" [ngModel]="status()" (ngModelChange)="status.set($event)"><option>Open</option><option>All</option><option>Pending</option><option>Dispatched</option><option>Rescued</option></select></div></div>
      @if (rows().length) {
        <div class="table-wrap"><table>
          <thead><tr><th>INCIDENT</th><th>PRIORITY</th><th>PEOPLE</th><th>HOPS</th><th>RECEIVED</th><th>STATUS</th></tr></thead>
          <tbody>
            @for (i of rows(); track i.messageId) {
              <tr class="clickable" [class.row-selected]="selected()!.messageId===i.messageId" (click)="selectedId.set(i.messageId)">
                <td><div class="table-workout"><span [class]="'exercise-avatar risk-bg-'+i.riskScore">{{icon(i.category)}}</span><div class="cell-stack"><strong>{{label(i.category)}}</strong><small>{{i.citizenId}} · {{i.note || 'No description'}}</small></div></div></td>
                <td><div class="prio"><span class="prio-pill" [class]="'prio-pill risk-'+i.riskScore">P{{i.priority}}</span><span class="prio-bar"><i [class]="'risk-bg-fill-'+i.riskScore" [style.width.%]="i.priority"></i></span></div></td>
                <td>{{i.people}}</td><td>{{i.hopCount}}</td><td>{{store.age(i.createdAtMs)}}</td>
                <td><span class="status-pill" [class.cancelled]="i.status==='Dispatched'" [class.done]="i.status==='Rescued'">{{i.status}}</span></td>
              </tr>
            }
          </tbody></table></div>
        <div class="table-footer">Showing {{rows().length}} of {{store.incidents().length}} incidents <span>Sorted by AI priority, then age.</span></div>
      } @else {
        <div class="empty-state history-empty"><div class="empty-icon">▤</div><strong>No incidents match.</strong><p>Try another filter, or use “Test gateway sync” to simulate packets arriving from a gateway.</p></div>
      }
    </section>

    <aside class="workout-aside detail-aside">
      @if (selected(); as s) {
        <div class="detail-head" [class]="'detail-head risk-grad-'+s.riskScore"><div class="eyebrow light">{{store.riskLabel(s.riskScore).toUpperCase()}} · PRIORITY {{s.priority}}/100</div><h3>{{label(s.category)}}</h3><small>{{s.citizenId}} · {{s.createdAtMs | date:'medium'}}</small></div>
        <div class="aside-copy">
          <p class="detail-note">{{s.note || 'No description provided.'}}</p>
          <div class="eyebrow">AI TRIAGE</div><p class="detail-triage">{{s.triageSummary}}</p>
          <div class="eyebrow" style="margin-top:14px">MESH PATH · {{s.hopCount}} HOP{{s.hopCount===1?'':'S'}}</div>
          <div class="hop-chain">@for (h of store.hops(s.hopPath); track $index) { <span class="hop" [class.gw]="h.startsWith('Gateway')" [class.origin]="$first">{{h}}</span> @if (!$last) { <i>→</i> } }</div>
          <div class="detail-grid"><div><small>People</small><strong>{{s.people}}</strong></div><div><small>Battery</small><strong>{{s.batteryPct ?? '—'}}{{s.batteryPct!=null?'%':''}}</strong></div><div><small>Mobility</small><strong>{{s.mobilityIssue?'Limited':'—'}}</strong></div><div><small>Gateway</small><strong>{{s.gatewayId}}</strong></div></div>
          <div class="coords">◎ {{s.latitude.toFixed(4)}}, {{s.longitude.toFixed(4)}}</div>
          @if (s.assignedTeamName) { <div class="assigned">☷ {{s.assignedTeamName}} assigned</div> }
          <div class="detail-actions">
            @if (s.status==='Pending') { <button class="btn btn-primary btn-full" (click)="store.dispatch(s.messageId)">Dispatch nearest team <span>→</span></button> }
            @if (s.status==='Dispatched') { <button class="btn btn-primary btn-full" (click)="store.markRescued(s.messageId)">Mark rescued <span>✓</span></button> }
            @if (s.status==='Rescued') { <div class="assigned ok">✓ Closed — team released</div> }
            <a class="btn btn-outline btn-full" routerLink="/map">Show on survival map</a>
          </div>
        </div>
      } @else { <div class="empty-state history-empty"><div class="empty-icon">◎</div><strong>Select an incident</strong><p>Details, mesh path and dispatch actions appear here.</p></div> }
    </aside>
  </div>
</section>`
})
export class IncidentsComponent {
  constructor(public store: RescueStore, public api: ApiService) {}
  filter = signal(''); risk = signal('All risks'); status = signal('Open'); selectedId = signal<string | null>(null);
  icon = categoryIcon; label = categoryLabel;
  rows = computed(() => {
    const q = this.filter().trim().toLowerCase(), r = this.risk(), st = this.status();
    return [...this.store.incidents()]
      .filter(i => (st === 'All' || (st === 'Open' ? i.status !== 'Rescued' : i.status === st))
        && (r === 'All risks' || this.store.riskLabel(i.riskScore) === r)
        && `${i.messageId} ${i.citizenId} ${i.note ?? ''} ${i.gatewayId} ${i.hopPath} ${i.category}`.toLowerCase().includes(q))
      .sort((a, b) => b.priority - a.priority || a.createdAtMs - b.createdAtMs);
  });
  selected = computed(() => this.rows().find(i => i.messageId === this.selectedId()) ?? this.rows()[0] ?? null);
}
