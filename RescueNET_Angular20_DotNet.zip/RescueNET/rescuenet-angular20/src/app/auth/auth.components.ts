import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiService } from '../core/api.service';

@Component({
  standalone: true, selector: 'app-login', imports: [CommonModule, FormsModule, RouterLink],
  template: `<div class="auth-layout"><section class="auth-art"><a class="brand brand-invert" routerLink="/"><span class="brand-mark">◉</span><span>rescue<span class="brand-light">net</span><small>WHEN THE NETWORK FAILS</small></span></a>
<div class="art-copy"><div class="pill-label"><span class="pulse"></span> MESH READY · NO TOWER REQUIRED</div><h1>Your phone is<br>the <em>network.</em></h1><p>RescueNET turns nearby phones into a temporary emergency network. SOS messages hop from phone to phone until they reach someone with a connection.</p>
<div class="art-stats"><div><strong>01</strong><span>Discover nearby phones</span></div><div><strong>02</strong><span>Hop, store &amp; forward</span></div><div><strong>03</strong><span>Reach rescue teams</span></div></div></div><div class="art-foot">Prioritised by AI. Delivered by people around you.</div></section>
<section class="auth-form-side"><div class="auth-card"><div class="mobile-brand brand"><span class="brand-mark">◉</span><span>rescue<span class="brand-light">net</span></span></div><div class="form-kicker">WELCOME BACK</div><h2>Stay connected.</h2><p class="muted">Sign in to your command center or personal SOS space.</p>
<form (ngSubmit)="submit()" #f="ngForm"><label>Email address</label><input type="email" name="email" [(ngModel)]="email" placeholder="you@example.com" required email autocomplete="email"><label>Password</label><input type="password" name="password" [(ngModel)]="password" placeholder="Enter your password" required minlength="6" autocomplete="current-password"><p class="form-error" *ngIf="error">{{error}}</p><button class="btn btn-primary btn-full" [disabled]="f.invalid||loading">{{loading?'Signing in…':'Sign in'}} <span>→</span></button></form>
<button type="button" class="demo-hint" (click)="useDemo()"><span>DEMO ACCOUNT</span> demo@rescuenet.app · Demo&#64;1234 &nbsp;<b>Fill in</b></button>
<div class="form-divider"><span>NEW TO RESCUENET?</span></div><a class="btn btn-outline btn-full" routerLink="/signup">Create your account</a><div class="auth-footnote">RescueNET is a prototype. Always keep official emergency numbers (112) available.</div></div></section></div>`
})
export class LoginComponent {
  email = ''; password = ''; loading = false; error = '';
  constructor(private api: ApiService, private router: Router) {}
  useDemo() { this.email = 'demo@rescuenet.app'; this.password = 'Demo@1234'; }
  async submit() { this.loading = true; this.error = ''; try { await this.api.login(this.email, this.password); this.router.navigateByUrl('/'); } catch (e: any) { this.error = e.message; } finally { this.loading = false; } }
}

@Component({
  standalone: true, selector: 'app-signup', imports: [CommonModule, FormsModule, RouterLink],
  template: `<div class="auth-layout"><section class="auth-art"><a class="brand brand-invert" routerLink="/"><span class="brand-mark">◉</span><span>rescue<span class="brand-light">net</span><small>WHEN THE NETWORK FAILS</small></span></a>
<div class="art-copy"><div class="pill-label"><span class="pulse"></span> EVERY PHONE STRENGTHENS THE MESH</div><h1>Be part of the<br><em>safety net.</em></h1><p>The more phones join, the further an SOS can travel. Join as a citizen to send and relay alerts, or as a responder to coordinate rescue from the command center.</p><div class="art-quote">“We are not building an SOS app that needs a network. We are building a network out of the phones around us.”</div></div><div class="art-foot">Prioritised by AI. Delivered by people around you.</div></section>
<section class="auth-form-side"><div class="auth-card"><div class="mobile-brand brand"><span class="brand-mark">◉</span><span>rescue<span class="brand-light">net</span></span></div><div class="form-kicker">GET STARTED</div><h2>Create your account.</h2><p class="muted">It takes under a minute. Works offline once installed.</p>
<form (ngSubmit)="submit()" #f="ngForm"><label>Full name</label><input name="name" [(ngModel)]="name" placeholder="Your name" required minlength="2" autocomplete="name"><label>Email address</label><input type="email" name="email" [(ngModel)]="email" placeholder="you@example.com" required email autocomplete="email"><label>Password</label><input type="password" name="password" [(ngModel)]="password" placeholder="At least 8 characters" required minlength="8" autocomplete="new-password">
<label>I am joining as</label><div class="role-toggle"><button type="button" [class.on]="role==='Citizen'" (click)="role='Citizen'"><strong>Citizen</strong><small>Send SOS &amp; relay alerts</small></button><button type="button" [class.on]="role==='Responder'" (click)="role='Responder'"><strong>Responder</strong><small>Dispatch &amp; coordinate</small></button></div>
<p class="form-error" *ngIf="error">{{error}}</p><button class="btn btn-primary btn-full" [disabled]="f.invalid||loading">{{loading?'Creating account…':'Create account'}} <span>→</span></button></form>
<div class="form-divider"><span>ALREADY A MEMBER?</span></div><a class="btn btn-outline btn-full" routerLink="/login">Sign in instead</a><div class="auth-footnote">Your location is only shared when you send an SOS or choose to share it.</div></div></section></div>`
})
export class SignupComponent {
  name = ''; email = ''; password = ''; role = 'Citizen'; loading = false; error = '';
  constructor(private api: ApiService, private router: Router) {}
  async submit() { this.loading = true; this.error = ''; try { await this.api.register(this.name, this.email, this.password, this.role); this.router.navigateByUrl('/'); } catch (e: any) { this.error = e.message; } finally { this.loading = false; } }
}
