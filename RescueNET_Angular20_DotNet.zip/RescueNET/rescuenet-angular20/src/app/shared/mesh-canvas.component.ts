import { AfterViewInit, Component, ElementRef, EventEmitter, Input, NgZone, OnDestroy, Output, ViewChild } from '@angular/core';
import { MeshNode, MeshService } from '../core/mesh.service';

const COLORS = { self: '#b4aaff', relay: '#8fa8ff', gateway: '#66d3a8', ble: '#f2b184', off: '#59627f' };

/** 3D Bluetooth-mesh visualisation: phones are nodes, links are radio range, glowing pulses are packets in flight. */
@Component({
  selector: 'app-mesh-canvas', standalone: true,
  template: `<div class="mesh-canvas" #wrap [style.height.px]="height">
    <canvas #cv (pointermove)="onMove($event)" (pointerdown)="onDown($event)" (pointerup)="onUp($event)" (pointerleave)="onLeave()" aria-label="3D Bluetooth mesh visualisation"></canvas>
    <div class="mesh-legend"><span><i style="background:#b4aaff"></i>This phone</span><span><i style="background:#8fa8ff"></i>Relay</span><span><i style="background:#66d3a8"></i>Gateway</span><span><i style="background:#f2b184"></i>Bluetooth device</span><span><i style="background:#ff7a8a"></i>Critical packet</span></div>
    <div class="mesh-hint">Drag to rotate</div></div>`
})
export class MeshCanvasComponent implements AfterViewInit, OnDestroy {
  @Input() height = 440;
  @Output() pick = new EventEmitter<string>();
  @ViewChild('cv', { static: true }) cv!: ElementRef<HTMLCanvasElement>;
  @ViewChild('wrap', { static: true }) wrap!: ElementRef<HTMLDivElement>;

  private raf = 0; private ro?: ResizeObserver;
  private w = 0; private h = 0; private rotY = -0.5; private rotX = 0.38;
  private dragging = false; private lastX = 0; private lastY = 0; private moved = false;
  private hover: MeshNode | null = null; private mx = 0; private my = 0;
  private projected = new Map<string, { x: number; y: number; f: number; z: number }>();
  private reduceMotion = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;

  constructor(private mesh: MeshService, private zone: NgZone) {}

  ngAfterViewInit() {
    this.resize();
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(this.wrap.nativeElement);
    this.zone.runOutsideAngular(() => { const loop = () => { this.draw(); this.raf = requestAnimationFrame(loop); }; loop(); });
  }
  ngOnDestroy() { cancelAnimationFrame(this.raf); this.ro?.disconnect(); }

  private resize() {
    const dpr = Math.min(2, window.devicePixelRatio || 1); const r = this.wrap.nativeElement.getBoundingClientRect();
    this.w = Math.max(280, r.width); this.h = Math.max(220, r.height);
    const c = this.cv.nativeElement; c.width = this.w * dpr; c.height = this.h * dpr; c.style.width = this.w + 'px'; c.style.height = this.h + 'px';
    c.getContext('2d')!.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  onDown(e: PointerEvent) { this.dragging = true; this.moved = false; this.lastX = e.clientX; this.lastY = e.clientY; (e.target as HTMLElement).setPointerCapture?.(e.pointerId); }
  onUp(e: PointerEvent) { this.dragging = false; if (!this.moved && this.hover) this.pick.emit(this.hover.id); (e.target as HTMLElement).releasePointerCapture?.(e.pointerId); }
  onLeave() { this.hover = null; }
  onMove(e: PointerEvent) {
    const r = this.cv.nativeElement.getBoundingClientRect(); this.mx = e.clientX - r.left; this.my = e.clientY - r.top;
    if (this.dragging) {
      const dx = e.clientX - this.lastX, dy = e.clientY - this.lastY;
      if (Math.abs(dx) + Math.abs(dy) > 2) this.moved = true;
      this.rotY += dx * 0.008; this.rotX = Math.max(-0.9, Math.min(1.1, this.rotX + dy * 0.006));
      this.lastX = e.clientX; this.lastY = e.clientY;
    }
  }

  private project(n: { x: number; y: number; z: number }) {
    const cy = Math.cos(this.rotY), sy = Math.sin(this.rotY), cx = Math.cos(this.rotX), sx = Math.sin(this.rotX);
    const x1 = n.x * cy + n.z * sy; const z1 = -n.x * sy + n.z * cy;
    const y2 = n.y * cx - z1 * sx; const z2 = n.y * sx + z1 * cx;
    const scale = Math.min(this.w / 250, this.h / 170); const f = 380 / (380 + z2 + 40);
    return { x: this.w / 2 + x1 * scale * f, y: this.h / 2 + y2 * scale * f, f, z: z2 };
  }

  private draw() {
    const ctx = this.cv.nativeElement.getContext('2d'); if (!ctx || !this.w) return;
    if (!this.dragging && !this.reduceMotion) this.rotY += 0.0022;
    ctx.clearRect(0, 0, this.w, this.h);
    const bg = ctx.createRadialGradient(this.w / 2, this.h / 2, 10, this.w / 2, this.h / 2, Math.max(this.w, this.h) * 0.7);
    bg.addColorStop(0, '#222c52'); bg.addColorStop(1, '#141b33'); ctx.fillStyle = bg; ctx.fillRect(0, 0, this.w, this.h);

    this.projected.clear();
    this.mesh.nodes.forEach(n => this.projected.set(n.id, this.project(n)));
    const active = new Set(this.mesh.pulses.map(p => [p.from, p.to].sort().join('|')));

    // radio links
    for (const [a, b] of this.mesh.links) {
      const pa = this.projected.get(a.id)!, pb = this.projected.get(b.id)!; const hot = active.has([a.id, b.id].sort().join('|'));
      ctx.strokeStyle = hot ? 'rgba(200,190,255,.8)' : `rgba(160,170,230,${0.1 + 0.12 * ((pa.f + pb.f) / 2)})`;
      ctx.lineWidth = hot ? 1.8 : 1; ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke();
    }

    // nodes, far to near so near ones overlap correctly
    const order = [...this.mesh.nodes].sort((a, b) => this.projected.get(b.id)!.z - this.projected.get(a.id)!.z);
    this.hover = null; let best = 16;
    for (const n of order) {
      const p = this.projected.get(n.id)!; const base = n.type === 'self' ? 9 : n.type === 'gateway' ? 8 : n.type === 'ble' ? 7 : 5.5;
      const r = base * p.f * (this.w < 520 ? 0.85 : 1); const color = !n.online ? COLORS.off : COLORS[n.type];
      const d = Math.hypot(p.x - this.mx, p.y - this.my); if (d < best) { best = d; this.hover = n; }
      if (n.online && (n.type === 'self' || this.mesh.isGateway(n))) { ctx.beginPath(); ctx.arc(p.x, p.y, r + 7 + 2 * Math.sin(Date.now() / 450), 0, 7); ctx.strokeStyle = color + '55'; ctx.lineWidth = 1.2; ctx.stroke(); }
      const g = ctx.createRadialGradient(p.x - r / 3, p.y - r / 3, 1, p.x, p.y, r); g.addColorStop(0, '#fff'); g.addColorStop(0.35, color); g.addColorStop(1, color);
      ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fillStyle = g; ctx.globalAlpha = n.online ? 0.95 : 0.55; ctx.fill(); ctx.globalAlpha = 1;
      if (!n.online) { ctx.strokeStyle = '#ff8a9a'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(p.x - r, p.y - r); ctx.lineTo(p.x + r, p.y + r); ctx.moveTo(p.x + r, p.y - r); ctx.lineTo(p.x - r, p.y + r); ctx.stroke(); }
      if (n.queue.length) { ctx.beginPath(); ctx.arc(p.x, p.y, r + 3.5, 0, 7); ctx.strokeStyle = '#ffb36b'; ctx.lineWidth = 2; ctx.stroke(); }
      if (n.type !== 'relay' || this.w > 640) {
        ctx.font = `600 ${n.type === 'relay' ? 9 : 10.5}px "DM Sans", sans-serif`; ctx.fillStyle = n.type === 'relay' ? 'rgba(210,216,245,.6)' : '#eef0ff'; ctx.textAlign = 'center';
        ctx.fillText(n.label, p.x, p.y - r - 7);
      }
    }

    // packet pulses
    for (const pulse of this.mesh.pulses) {
      const a = this.projected.get(pulse.from), b = this.projected.get(pulse.to); if (!a || !b) continue;
      const t = Math.min(1, pulse.t); const x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t; const t0 = Math.max(0, t - 0.22);
      const color = pulse.fail ? '#8a93b3' : pulse.hot ? '#ff7a8a' : '#e3deff';
      const tr = ctx.createLinearGradient(a.x + (b.x - a.x) * t0, a.y + (b.y - a.y) * t0, x, y); tr.addColorStop(0, color + '00'); tr.addColorStop(1, color);
      ctx.strokeStyle = tr; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(a.x + (b.x - a.x) * t0, a.y + (b.y - a.y) * t0); ctx.lineTo(x, y); ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y, pulse.hot ? 6.5 : 4.5, 0, 7); ctx.fillStyle = color; ctx.shadowColor = color; ctx.shadowBlur = pulse.fail ? 0 : 14; ctx.globalAlpha = pulse.fail ? Math.max(0.2, 1 - t) : 1; ctx.fill(); ctx.shadowBlur = 0; ctx.globalAlpha = 1;
    }

    // hover card
    if (this.hover && !this.dragging) {
      const n = this.hover; const p = this.projected.get(n.id)!;
      const lines = [`${n.label} · ${n.type === 'self' ? 'this phone' : n.type}`, `${n.online ? 'online' : 'out of range'} · battery ${Math.round(n.battery)}%`, `queue ${n.queue.length} · relayed ${n.relayed}`];
      ctx.font = '600 10px "DM Sans", sans-serif'; const wBox = Math.max(...lines.map(l => ctx.measureText(l).width)) + 18;
      const bx = Math.min(this.w - wBox - 6, Math.max(6, p.x + 12)), by = Math.min(this.h - 52, Math.max(6, p.y - 22));
      ctx.fillStyle = 'rgba(255,255,255,.96)'; ctx.beginPath(); ctx.roundRect(bx, by, wBox, 46, 8); ctx.fill();
      ctx.fillStyle = '#17233b'; ctx.textAlign = 'left'; lines.forEach((l, i) => { ctx.fillStyle = i ? '#7b8497' : '#17233b'; ctx.fillText(l, bx + 9, by + 16 + i * 12); });
    }
  }
}
