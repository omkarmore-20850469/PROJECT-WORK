import { Component } from '@angular/core';
import { NgIf } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { ApiService } from './core/api.service';
import { MeshService } from './core/mesh.service';
import { RescueStore } from './core/store.service';

@Component({
  selector: 'app-root', standalone: true, imports: [RouterOutlet, RouterLink, RouterLinkActive, NgIf],
  template: `
<div class="app-shell">
  <aside class="sidebar" *ngIf="api.user()">
    <a class="brand" routerLink="/"><span class="brand-mark">◉</span><span>rescue<span class="brand-light">net</span><small>WHEN THE NETWORK FAILS</small></span></a>
    <div class="nav-label">WORKSPACE</div>
    <a class="nav-item" routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}"><span>◫</span> Overview</a>
    <a class="nav-item" routerLink="/sos" routerLinkActive="active"><span>✚</span> Send SOS</a>
    <a class="nav-item" routerLink="/incidents" routerLinkActive="active"><span>▤</span> Incidents</a>
    <div class="nav-label nav-label-2">NETWORK</div>
    <a class="nav-item" routerLink="/mesh" routerLinkActive="active"><span>⌁</span> Mesh network</a>
    <a class="nav-item" routerLink="/map" routerLinkActive="active"><span>◎</span> Survival map</a>
    <a class="nav-item" routerLink="/teams" routerLinkActive="active"><span>☷</span> Rescue teams</a>
    <a class="nav-item" routerLink="/settings" routerLinkActive="active"><span>⚙</span> Activity &amp; settings</a>
    <div class="sidebar-bottom">
      <div class="mini-profile"><div class="avatar">{{ initials() }}</div><div class="profile-copy"><strong>{{api.user()?.displayName}}</strong><small>{{api.user()?.role}} account</small></div><button class="icon-btn" title="Sign out" (click)="logout()">↪</button></div>
      <div class="sidebar-note"><span class="pulse" [class.pulse-off]="!mesh.stats().online"></span> Mesh active · {{ nearbyCount() }} devices nearby</div>
    </div>
  </aside>
  <main class="main-area" [class.auth-main]="!api.user()">
    <header class="topbar" *ngIf="api.user()">
      <div><div class="eyebrow">PHONE-TO-PHONE EMERGENCY NETWORK</div><h2>{{ pageTitle() }}</h2></div>
      <div class="topbar-right">
        <span class="net-chip" [class.net-down]="!store.apiOnline()" title="Connection from this phone to the command center"><span class="pulse" [class.pulse-off]="!store.apiOnline()"></span>{{ store.apiOnline() ? (store.liveLink() ? 'Cloud · live link' : 'Cloud · online') : 'Cloud unreachable' }}</span>
        <span class="net-chip" *ngIf="store.pendingCount()" title="Packets waiting to sync">⇅ {{store.pendingCount()}} queued</span>
        <span class="date-chip">◷ &nbsp; {{today}}</span>
        <div class="avatar avatar-small">{{initials()}}</div>
      </div>
    </header>
    <router-outlet />
    <footer class="footer" *ngIf="api.user()">The internet can go down. The network doesn’t have to. <span>◉</span></footer>
  </main>
</div>
<div class="toast" *ngIf="api.toast()" role="status">{{api.toast()}}</div>`
})
export class AppComponent {
  today = new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  constructor(public api: ApiService, public mesh: MeshService, public store: RescueStore, private router: Router) {}
  initials() { return (this.api.user()?.displayName || 'RN').split(' ').map(x => x[0]).join('').slice(0, 2).toUpperCase(); }
  nearbyCount() { const s = this.mesh.stats(); return Math.max(0, s.online - 1); }
  pageTitle() {
    const p = this.router.url;
    return p.startsWith('/sos') ? 'Send an SOS' : p.startsWith('/incidents') ? 'Incident command' : p.startsWith('/mesh') ? 'Live mesh network'
      : p.startsWith('/map') ? 'Live survival map' : p.startsWith('/teams') ? 'Rescue teams' : p.startsWith('/settings') ? 'Activity & settings' : 'Network overview';
  }
  logout() { this.api.logout(); this.router.navigateByUrl('/login'); }
}
